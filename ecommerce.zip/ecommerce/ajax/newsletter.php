<?php
require_once '../config.php';
header('Content-Type: application/json');
$db    = Database::getInstance()->getConnection();
$email = sanitize($_POST['email'] ?? '');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { echo json_encode(['success'=>false,'message'=>'Invalid email address']); exit; }
// Store in settings or a newsletter table - basic implementation
echo json_encode(['success'=>true,'message'=>'Successfully subscribed! 🎉 Watch for exclusive deals.']);

<?php
require_once '../config.php';
header('Content-Type: application/json');

$db = Database::getInstance()->getConnection();
$action = $_REQUEST['action'] ?? '';

// Helper: get/create session cart key
if (!isLoggedIn() && !isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

function getCartItems($db) {
    if (isLoggedIn()) {
        $uid = (int)$_SESSION['user_id'];
        $result = $db->query("SELECT c.id, c.product_id, c.quantity, c.price, p.name, p.featured_image as image, p.stock
            FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = $uid");
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = ['id'=>$row['id'],'product_id'=>$row['product_id'],'name'=>$row['name'],'image'=>$row['image'],'price'=>floatval($row['price']),'qty'=>intval($row['quantity']),'stock'=>intval($row['stock'])];
        }
        return $items;
    }
    return $_SESSION['cart'] ?? [];
}

function getCartCount($db) {
    $items = getCartItems($db);
    return array_sum(array_column($items, 'qty'));
}

switch ($action) {
    case 'get':
        echo json_encode(['success'=>true,'items'=>getCartItems($db),'count'=>getCartCount($db)]);
        break;

    case 'add':
        $pid = (int)($_POST['product_id'] ?? 0);
        $qty = max(1, (int)($_POST['quantity'] ?? 1));
        if (!$pid) { echo json_encode(['success'=>false,'message'=>'Invalid product']); exit; }

        // Get product
        $result = $db->query("SELECT id, name, price, sale_price, stock, status FROM products WHERE id=$pid AND status='active' AND approval_status='approved'");
        if (!$result || !$result->num_rows) { echo json_encode(['success'=>false,'message'=>'Product not available']); exit; }
        $prod = $result->fetch_assoc();
        $price = $prod['sale_price'] ?? $prod['price'];

        if (isLoggedIn()) {
            $uid = (int)$_SESSION['user_id'];
            // Check if already in cart
            $ex = $db->query("SELECT id, quantity FROM cart WHERE user_id=$uid AND product_id=$pid");
            if ($ex && $ex->num_rows) {
                $row = $ex->fetch_assoc();
                $newQty = $row['quantity'] + $qty;
                if ($newQty > $prod['stock']) $newQty = $prod['stock'];
                $db->query("UPDATE cart SET quantity=$newQty WHERE id={$row['id']}");
            } else {
                $db->query("INSERT INTO cart (user_id,product_id,quantity,price) VALUES ($uid,$pid,$qty,$price)");
            }
        } else {
            $found = false;
            foreach ($_SESSION['cart'] as &$item) {
                if ($item['product_id'] == $pid) { $item['qty'] = min($item['qty']+$qty, $prod['stock']); $found=true; break; }
            }
            if (!$found) {
                $_SESSION['cart'][] = ['id'=>uniqid(),'product_id'=>$pid,'name'=>$prod['name'],'image'=>null,'price'=>floatval($price),'qty'=>$qty,'stock'=>(int)$prod['stock']];
            }
        }
        echo json_encode(['success'=>true,'message'=>'Added to cart','cart_count'=>getCartCount($db)]);
        break;

    case 'increase':
    case 'decrease':
        $itemId = $db->escape($_POST['item_id'] ?? '');
        if (isLoggedIn()) {
            $uid = (int)$_SESSION['user_id'];
            $row = $db->query("SELECT c.id,c.quantity,p.stock FROM cart c JOIN products p ON c.product_id=p.id WHERE c.id=$itemId AND c.user_id=$uid")->fetch_assoc();
            if ($row) {
                $newQty = $action==='increase' ? $row['quantity']+1 : $row['quantity']-1;
                if ($newQty<=0) $db->query("DELETE FROM cart WHERE id=$itemId");
                elseif ($newQty<=$row['stock']) $db->query("UPDATE cart SET quantity=$newQty WHERE id=$itemId");
            }
        } else {
            foreach ($_SESSION['cart'] as $k=>&$item) {
                if ($item['id'] == $itemId) {
                    $item['qty'] = $action==='increase' ? $item['qty']+1 : $item['qty']-1;
                    if ($item['qty']<=0) unset($_SESSION['cart'][$k]);
                    break;
                }
            }
            $_SESSION['cart'] = array_values($_SESSION['cart']);
        }
        echo json_encode(['success'=>true,'cart_count'=>getCartCount($db)]);
        break;

    case 'remove':
        $itemId = $db->escape($_POST['item_id'] ?? '');
        if (isLoggedIn()) {
            $uid=(int)$_SESSION['user_id'];
            $db->query("DELETE FROM cart WHERE id=$itemId AND user_id=$uid");
        } else {
            $_SESSION['cart'] = array_values(array_filter($_SESSION['cart'], fn($i)=>$i['id']!=$itemId));
        }
        echo json_encode(['success'=>true,'cart_count'=>getCartCount($db)]);
        break;

    case 'clear':
        if (isLoggedIn()) { $uid=(int)$_SESSION['user_id']; $db->query("DELETE FROM cart WHERE user_id=$uid"); }
        else { $_SESSION['cart']=[]; }
        echo json_encode(['success'=>true]);
        break;

    default:
        echo json_encode(['success'=>false,'message'=>'Invalid action']);
}

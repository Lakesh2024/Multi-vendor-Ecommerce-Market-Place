<?php
// ajax/search.php
require_once '../config.php';
header('Content-Type: application/json');
$db = Database::getInstance()->getConnection();
$q  = sanitize($_GET['q'] ?? '');
if (strlen($q) < 2) { echo json_encode([]); exit; }
$qs = $db->real_escape_string($q);
$r  = $db->query("SELECT p.id,p.name,p.slug,p.featured_image,COALESCE(p.sale_price,p.price) as price FROM products p WHERE p.status='active' AND p.approval_status='approved' AND p.name LIKE '%$qs%' LIMIT 8");
$results = [];
while ($row = $r->fetch_assoc()) $results[] = $row;
echo json_encode($results);

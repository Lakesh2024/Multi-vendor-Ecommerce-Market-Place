<?php
// ajax/wishlist.php
require_once '../config.php';
header('Content-Type: application/json');
if (!isLoggedIn()) { echo json_encode(['success'=>false,'message'=>'Please login']); exit; }
$db = Database::getInstance()->getConnection();
$uid = (int)$_SESSION['user_id'];
$pid = (int)($_POST['product_id'] ?? 0);
if (!$pid) { echo json_encode(['success'=>false]); exit; }

$exists = $db->query("SELECT id FROM wishlist WHERE user_id=$uid AND product_id=$pid");
if ($exists && $exists->num_rows) {
    $db->query("DELETE FROM wishlist WHERE user_id=$uid AND product_id=$pid");
    echo json_encode(['success'=>true,'message'=>'Removed from wishlist','action'=>'removed']);
} else {
    $db->query("INSERT INTO wishlist (user_id,product_id) VALUES ($uid,$pid)");
    echo json_encode(['success'=>true,'message'=>'Added to wishlist!','action'=>'added']);
}

<?php
require_once '../config.php';
if (!isLoggedIn() || !isAdmin()) redirect('../login.php');
$db = Database::getInstance()->getConnection();

// Dashboard stats
$total_users    = $db->query("SELECT COUNT(*) as c FROM users WHERE role='customer'")->fetch_assoc()['c'];
$total_vendors  = $db->query("SELECT COUNT(*) as c FROM vendors")->fetch_assoc()['c'];
$total_products = $db->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$total_orders   = $db->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
$total_revenue  = $db->query("SELECT COALESCE(SUM(total),0) as r FROM orders WHERE payment_status='paid'")->fetch_assoc()['r'];
$pending_vendors= $db->query("SELECT COUNT(*) as c FROM vendors WHERE status='pending'")->fetch_assoc()['c'];
$pending_prods  = $db->query("SELECT COUNT(*) as c FROM products WHERE approval_status='pending'")->fetch_assoc()['c'];
$today_orders   = $db->query("SELECT COUNT(*) as c FROM orders WHERE DATE(created_at)=CURDATE()")->fetch_assoc()['c'];

// Recent orders
$recent_orders = $db->query("SELECT o.*,u.name as customer FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC LIMIT 8");

// Pending vendors
$pend_vendors = $db->query("SELECT v.*,u.name,u.email FROM vendors v JOIN users u ON v.user_id=u.id WHERE v.status='pending' ORDER BY v.created_at DESC LIMIT 5");

// Top vendors
$top_vendors = $db->query("SELECT v.store_name,v.total_sales,v.total_orders,v.rating FROM vendors v WHERE v.status='active' ORDER BY v.total_sales DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard - ECommerce</title>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{--primary:#2874f0;--secondary:#fb641b;--success:#388e3c;--warning:#f57c00;--danger:#d32f2f;--purple:#7c3aed;--text:#212121;--light:#878787;--border:#e0e0e0;--bg:#f1f3f6;--sidebar:260px;}
body{font-family:'Nunito',sans-serif;background:var(--bg);display:flex;min-height:100vh;}
a{text-decoration:none;color:inherit;}
/* SIDEBAR */
.sidebar{width:var(--sidebar);background:#0f1923;min-height:100vh;position:fixed;top:0;left:0;z-index:100;display:flex;flex-direction:column;overflow-y:auto;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,0.1) transparent;}
.sb-logo{padding:22px 22px;border-bottom:1px solid rgba(255,255,255,0.06);}
.sb-logo a{font-size:1.25rem;font-weight:900;color:#fff;display:flex;align-items:center;gap:10px;}
.sb-logo span{font-size:0.65rem;color:rgba(255,255,255,0.4);display:block;margin-top:2px;}
.sb-menu{flex:1;padding:12px 0;}
.sb-section{padding:10px 20px 4px;font-size:0.62rem;font-weight:900;color:rgba(255,255,255,0.25);text-transform:uppercase;letter-spacing:1.5px;}
.sb-item{display:flex;align-items:center;gap:12px;padding:11px 22px;color:rgba(255,255,255,0.6);font-size:0.84rem;font-weight:600;cursor:pointer;transition:0.2s;position:relative;}
.sb-item:hover,.sb-item.active{background:rgba(40,116,240,0.15);color:#fff;}
.sb-item.active::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--primary);border-radius:0 3px 3px 0;}
.sb-item i{width:18px;text-align:center;font-size:0.95rem;}
.sb-badge{background:var(--danger);color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:10px;margin-left:auto;}
.sb-badge.yellow{background:var(--warning);}
/* MAIN */
.main{margin-left:var(--sidebar);flex:1;}
.topbar{background:#fff;height:62px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;box-shadow:0 1px 8px rgba(0,0,0,0.07);position:sticky;top:0;z-index:50;}
.topbar-left{display:flex;align-items:center;gap:16px;}
.topbar-left h2{font-size:1.1rem;font-weight:800;}
.breadcrumb{font-size:0.78rem;color:var(--light);}
.topbar-right{display:flex;align-items:center;gap:14px;}
.tb-icon-btn{width:38px;height:38px;border-radius:10px;background:var(--bg);display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--light);position:relative;border:none;}
.tb-icon-btn .dot{position:absolute;top:6px;right:6px;width:9px;height:9px;background:var(--danger);border-radius:50%;border:2px solid #fff;}
.admin-user{display:flex;align-items:center;gap:10px;cursor:pointer;padding:6px 12px;border-radius:10px;transition:0.2s;}
.admin-user:hover{background:var(--bg);}
.admin-avatar{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--primary),#4facfe);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:0.9rem;}
.admin-name{font-size:0.85rem;font-weight:700;}
.admin-role{font-size:0.7rem;color:var(--light);}
/* CONTENT */
.content{padding:24px 28px;}
/* STATS */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:22px;}
.stat-card{background:#fff;border-radius:14px;padding:20px;box-shadow:0 2px 12px rgba(0,0,0,0.06);position:relative;overflow:hidden;}
.stat-card::after{content:'';position:absolute;right:-20px;top:-20px;width:80px;height:80px;border-radius:50%;opacity:0.08;}
.stat-card:nth-child(1)::after{background:var(--primary);}
.stat-card:nth-child(2)::after{background:var(--secondary);}
.stat-card:nth-child(3)::after{background:var(--success);}
.stat-card:nth-child(4)::after{background:var(--warning);}
.stat-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;}
.stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:#fff;}
.si-blue{background:linear-gradient(135deg,var(--primary),#4facfe);}
.si-orange{background:linear-gradient(135deg,var(--secondary),#ffd200);}
.si-green{background:linear-gradient(135deg,var(--success),#43e97b);}
.si-yellow{background:linear-gradient(135deg,var(--warning),#ffd200);}
.si-purple{background:linear-gradient(135deg,var(--purple),#a78bfa);}
.si-red{background:linear-gradient(135deg,var(--danger),#f093fb);}
.stat-change{font-size:0.72rem;font-weight:700;padding:3px 8px;border-radius:20px;}
.change-up{background:#e8f5e9;color:#2e7d32;}
.change-down{background:#fce4e4;color:#c62828;}
.stat-value{font-size:2rem;font-weight:900;color:var(--text);line-height:1;}
.stat-label{font-size:0.78rem;color:var(--light);margin-top:5px;}
/* CARDS */
.grid-2{display:grid;grid-template-columns:2fr 1fr;gap:18px;margin-bottom:18px;}
.grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-bottom:18px;}
.card{background:#fff;border-radius:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);overflow:hidden;}
.card-header{padding:16px 22px;border-bottom:1px solid var(--bg);display:flex;align-items:center;justify-content:space-between;}
.card-title{font-size:0.95rem;font-weight:800;color:var(--text);}
.card-action{font-size:0.78rem;font-weight:700;color:var(--primary);cursor:pointer;}
.chart-wrap{padding:16px 20px;height:250px;}
/* TABLE */
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;}
th{text-align:left;padding:10px 16px;font-size:0.72rem;font-weight:800;color:var(--light);text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid var(--bg);white-space:nowrap;}
td{padding:11px 16px;font-size:0.83rem;border-bottom:1px solid var(--bg);color:var(--text);}
tr:last-child td{border-bottom:none;}
tr:hover td{background:var(--bg);}
.badge{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;font-size:0.7rem;font-weight:700;}
.b-pending{background:#fff3e0;color:#e65100;}
.b-confirmed{background:#e3f2fd;color:#1565c0;}
.b-processing{background:#f3e5f5;color:#6a1b9a;}
.b-shipped{background:#e0f7fa;color:#006064;}
.b-delivered{background:#e8f5e9;color:#2e7d32;}
.b-cancelled{background:#fce4e4;color:#c62828;}
.b-active{background:#e8f5e9;color:#2e7d32;}
.b-inactive{background:#fce4e4;color:#c62828;}
.b-suspended{background:#fce4e4;color:#c62828;}
.b-approved{background:#e8f5e9;color:#2e7d32;}
.b-rejected{background:#fce4e4;color:#c62828;}
.btn-sm{padding:5px 12px;border-radius:6px;font-size:0.74rem;font-weight:700;border:none;cursor:pointer;transition:0.2s;}
.btn-approve{background:#e8f5e9;color:var(--success);}
.btn-approve:hover{background:var(--success);color:#fff;}
.btn-reject{background:#fce4e4;color:var(--danger);}
.btn-reject:hover{background:var(--danger);color:#fff;}
.btn-view{background:#e3f2fd;color:var(--primary);}
.btn-view:hover{background:var(--primary);color:#fff;}
/* MINI METRIC */
.mini-metrics{display:flex;flex-direction:column;gap:14px;padding:18px 22px;}
.mm-item{display:flex;align-items:center;justify-content:space-between;}
.mm-label{font-size:0.8rem;color:var(--light);font-weight:600;}
.mm-value{font-size:0.88rem;font-weight:800;color:var(--text);}
.mm-bar{height:6px;background:var(--bg);border-radius:3px;margin-top:5px;overflow:hidden;}
.mm-fill{height:100%;border-radius:3px;}
/* ALERTS */
.alert-list{padding:14px 18px;display:flex;flex-direction:column;gap:10px;}
.alert-item{display:flex;align-items:flex-start;gap:12px;padding:12px;background:var(--bg);border-radius:8px;}
.alert-icon{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:0.85rem;}
.alert-text h5{font-size:0.82rem;font-weight:700;}
.alert-text p{font-size:0.75rem;color:var(--light);margin-top:2px;}
.alert-time{font-size:0.7rem;color:var(--light);margin-left:auto;white-space:nowrap;}
@media(max-width:1024px){.stats-grid{grid-template-columns:repeat(2,1fr);}.grid-2{grid-template-columns:1fr;}.grid-3{grid-template-columns:1fr;}}
@media(max-width:768px){.sidebar{transform:translateX(-100%);}.main{margin-left:0;}}
</style>
</head>
<body>
<!-- SIDEBAR -->
<aside class="sidebar">
  <div class="sb-logo">
    <a href="../index.php">🛒 ECommerce</a>
    <span>Admin Control Panel</span>
  </div>
  <nav class="sb-menu">
    <div class="sb-section">Overview</div>
    <a href="dashboard.php" class="sb-item active"><i class="fas fa-th-large"></i> Dashboard</a>
    <a href="analytics.php" class="sb-item"><i class="fas fa-chart-bar"></i> Analytics</a>
    <div class="sb-section">Management</div>
    <a href="vendors.php" class="sb-item"><i class="fas fa-store"></i> Vendors <?php if($pending_vendors): ?><span class="sb-badge"><?= $pending_vendors ?></span><?php endif; ?></a>
    <a href="customers.php" class="sb-item"><i class="fas fa-users"></i> Customers</a>
    <a href="products.php" class="sb-item"><i class="fas fa-box"></i> Products <?php if($pending_prods): ?><span class="sb-badge yellow"><?= $pending_prods ?></span><?php endif; ?></a>
    <a href="categories.php" class="sb-item"><i class="fas fa-th-list"></i> Categories</a>
    <div class="sb-section">Orders & Finance</div>
    <a href="orders.php" class="sb-item"><i class="fas fa-shopping-bag"></i> All Orders <span class="sb-badge"><?= $today_orders ?></span></a>
    <a href="payouts.php" class="sb-item"><i class="fas fa-wallet"></i> Payouts</a>
    <a href="transactions.php" class="sb-item"><i class="fas fa-exchange-alt"></i> Transactions</a>
    <a href="commissions.php" class="sb-item"><i class="fas fa-percent"></i> Commission Rules</a>
    <div class="sb-section">Marketing</div>
    <a href="coupons.php" class="sb-item"><i class="fas fa-ticket-alt"></i> Coupons</a>
    <a href="banners.php" class="sb-item"><i class="fas fa-images"></i> Banners</a>
    <a href="flash-sales.php" class="sb-item"><i class="fas fa-bolt"></i> Flash Sales</a>
    <div class="sb-section">Support</div>
    <a href="returns.php" class="sb-item"><i class="fas fa-undo"></i> Returns</a>
    <a href="disputes.php" class="sb-item"><i class="fas fa-gavel"></i> Disputes</a>
    <a href="messages.php" class="sb-item"><i class="fas fa-comments"></i> Messages</a>
    <div class="sb-section">System</div>
    <a href="settings.php" class="sb-item"><i class="fas fa-cog"></i> Settings</a>
    <a href="activity-logs.php" class="sb-item"><i class="fas fa-history"></i> Activity Logs</a>
    <a href="../logout.php" class="sb-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </nav>
</aside>

<!-- MAIN -->
<main class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h2>📊 Admin Dashboard</h2>
      <span class="breadcrumb">Home / Dashboard</span>
    </div>
    <div class="topbar-right">
      <button class="tb-icon-btn"><i class="fas fa-bell"></i><div class="dot"></div></button>
      <button class="tb-icon-btn"><i class="fas fa-search"></i></button>
      <div class="admin-user">
        <div class="admin-avatar">A</div>
        <div><div class="admin-name">Super Admin</div><div class="admin-role">Administrator</div></div>
      </div>
    </div>
  </div>

  <div class="content">
    <!-- STATS ROW 1 -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-icon si-blue"><i class="fas fa-rupee-sign"></i></div>
          <span class="stat-change change-up"><i class="fas fa-arrow-up"></i> 18%</span>
        </div>
        <div class="stat-value">₹<?= number_format($total_revenue/1000,1) ?>K</div>
        <div class="stat-label">Total Revenue (GMV)</div>
      </div>
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-icon si-orange"><i class="fas fa-shopping-bag"></i></div>
          <span class="stat-change change-up"><i class="fas fa-arrow-up"></i> 12%</span>
        </div>
        <div class="stat-value"><?= number_format($total_orders) ?></div>
        <div class="stat-label">Total Orders</div>
      </div>
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-icon si-green"><i class="fas fa-users"></i></div>
          <span class="stat-change change-up"><i class="fas fa-arrow-up"></i> 9%</span>
        </div>
        <div class="stat-value"><?= number_format($total_users) ?></div>
        <div class="stat-label">Registered Customers</div>
      </div>
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-icon si-yellow"><i class="fas fa-store"></i></div>
          <span class="stat-change change-up"><i class="fas fa-arrow-up"></i> 5%</span>
        </div>
        <div class="stat-value"><?= number_format($total_vendors) ?></div>
        <div class="stat-label">Active Vendors</div>
      </div>
    </div>

    <div class="stats-grid" style="margin-bottom:22px;">
      <div class="stat-card">
        <div class="stat-top"><div class="stat-icon si-purple"><i class="fas fa-box"></i></div><span class="stat-change change-up">+<?= $pending_prods ?> pending</span></div>
        <div class="stat-value"><?= number_format($total_products) ?></div>
        <div class="stat-label">Total Products Listed</div>
      </div>
      <div class="stat-card">
        <div class="stat-top"><div class="stat-icon si-red"><i class="fas fa-calendar-day"></i></div><span class="stat-change change-up">Today</span></div>
        <div class="stat-value"><?= $today_orders ?></div>
        <div class="stat-label">Orders Today</div>
      </div>
      <div class="stat-card">
        <div class="stat-top"><div class="stat-icon si-orange"><i class="fas fa-clock"></i></div><span class="stat-change change-down"><?= $pending_vendors ?> waiting</span></div>
        <div class="stat-value"><?= $pending_vendors ?></div>
        <div class="stat-label">Vendors Pending Approval</div>
      </div>
      <div class="stat-card">
        <div class="stat-top"><div class="stat-icon si-green"><i class="fas fa-percent"></i></div><span class="stat-change change-up">Platform</span></div>
        <div class="stat-value">10%</div>
        <div class="stat-label">Default Commission Rate</div>
      </div>
    </div>

    <!-- CHART + SIDE -->
    <div class="grid-2">
      <div class="card">
        <div class="card-header">
          <span class="card-title">📈 Revenue & Orders (Last 7 Days)</span>
          <a href="analytics.php" class="card-action">Full Report →</a>
        </div>
        <div class="chart-wrap">
          <canvas id="mainChart"></canvas>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">🍩 Order Status</span></div>
        <div class="chart-wrap" style="height:200px;">
          <canvas id="statusChart"></canvas>
        </div>
        <div class="mini-metrics">
          <div class="mm-item"><span class="mm-label">Delivered</span><span class="mm-value" style="color:var(--success);">68%</span></div>
          <div class="mm-bar"><div class="mm-fill" style="width:68%;background:var(--success);"></div></div>
          <div class="mm-item"><span class="mm-label">Processing</span><span class="mm-value" style="color:var(--primary);">18%</span></div>
          <div class="mm-bar"><div class="mm-fill" style="width:18%;background:var(--primary);"></div></div>
          <div class="mm-item"><span class="mm-label">Cancelled</span><span class="mm-value" style="color:var(--danger);">8%</span></div>
          <div class="mm-bar"><div class="mm-fill" style="width:8%;background:var(--danger);"></div></div>
        </div>
      </div>
    </div>

    <!-- ORDERS + VENDORS -->
    <div class="grid-2">
      <div class="card">
        <div class="card-header">
          <span class="card-title">🛍️ Recent Orders</span>
          <a href="orders.php" class="card-action">View All →</a>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Order #</th><th>Customer</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              <?php if($recent_orders&&$recent_orders->num_rows): while($o=$recent_orders->fetch_assoc()): ?>
              <tr>
                <td>#<?= $o['order_number'] ?></td>
                <td><?= htmlspecialchars(substr($o['customer'],0,18)) ?></td>
                <td>₹<?= number_format($o['total'],2) ?></td>
                <td><span class="badge b-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
                <td><?= date('d M',strtotime($o['created_at'])) ?></td>
              </tr>
              <?php endwhile; else: ?>
              <tr><td colspan="5" style="text-align:center;padding:24px;color:var(--light);">No orders yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <span class="card-title">⏳ Pending Approvals</span>
          <a href="vendors.php?status=pending" class="card-action">View All →</a>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Vendor</th><th>Email</th><th>Action</th></tr></thead>
            <tbody>
              <?php if($pend_vendors&&$pend_vendors->num_rows): while($v=$pend_vendors->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars(substr($v['store_name'],0,18)) ?></td>
                <td style="font-size:0.75rem;"><?= htmlspecialchars(substr($v['email'],0,22)) ?></td>
                <td style="display:flex;gap:6px;">
                  <button class="btn-sm btn-approve" onclick="approveVendor(<?= $v['id'] ?>)">✓</button>
                  <button class="btn-sm btn-reject" onclick="rejectVendor(<?= $v['id'] ?>)">✗</button>
                  <a href="vendor-detail.php?id=<?= $v['id'] ?>" class="btn-sm btn-view">View</a>
                </td>
              </tr>
              <?php endwhile; else: ?>
              <tr><td colspan="3" style="text-align:center;padding:24px;color:var(--light);">No pending vendors</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- TOP VENDORS + ALERTS -->
    <div class="grid-3">
      <div class="card" style="grid-column:span 2;">
        <div class="card-header">
          <span class="card-title">🏆 Top Performing Vendors</span>
          <a href="vendors.php" class="card-action">Manage All →</a>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>#</th><th>Store</th><th>Total Sales</th><th>Orders</th><th>Rating</th><th>Status</th></tr></thead>
            <tbody>
              <?php if($top_vendors&&$top_vendors->num_rows): $i=1; while($v=$top_vendors->fetch_assoc()): ?>
              <tr>
                <td><strong>#<?= $i++ ?></strong></td>
                <td><?= htmlspecialchars($v['store_name']) ?></td>
                <td>₹<?= number_format($v['total_sales']) ?></td>
                <td><?= number_format($v['total_orders']) ?></td>
                <td><?= $v['rating']>0?number_format($v['rating'],1):'—' ?>★</td>
                <td><span class="badge b-active">Active</span></td>
              </tr>
              <?php endwhile; else: for($i=1;$i<=5;$i++): ?>
              <tr>
                <td>#<?= $i ?></td><td>Vendor <?= $i ?></td>
                <td>₹<?= number_format(rand(50000,500000)) ?></td>
                <td><?= rand(100,999) ?></td>
                <td>4.<?= rand(2,9) ?>★</td>
                <td><span class="badge b-active">Active</span></td>
              </tr>
              <?php endfor; endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">🔔 System Alerts</span></div>
        <div class="alert-list">
          <?php if($pending_vendors>0): ?>
          <div class="alert-item">
            <div class="alert-icon" style="background:#fff3e0;color:var(--warning);"><i class="fas fa-store"></i></div>
            <div class="alert-text"><h5><?= $pending_vendors ?> vendors pending</h5><p>Need KYC approval</p></div>
          </div>
          <?php endif; ?>
          <?php if($pending_prods>0): ?>
          <div class="alert-item">
            <div class="alert-icon" style="background:#e3f2fd;color:var(--primary);"><i class="fas fa-box"></i></div>
            <div class="alert-text"><h5><?= $pending_prods ?> products</h5><p>Awaiting approval</p></div>
          </div>
          <?php endif; ?>
          <div class="alert-item">
            <div class="alert-icon" style="background:#e8f5e9;color:var(--success);"><i class="fas fa-check-circle"></i></div>
            <div class="alert-text"><h5>System running well</h5><p>All services operational</p></div>
          </div>
          <div class="alert-item">
            <div class="alert-icon" style="background:#f3e5f5;color:var(--purple);"><i class="fas fa-calendar"></i></div>
            <div class="alert-text"><h5><?= $today_orders ?> orders today</h5><p>Normal traffic volume</p></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
// Main Revenue Chart
new Chart(document.getElementById('mainChart'), {
  type: 'line',
  data: {
    labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
    datasets: [
      { label:'Revenue (₹)', data:[45000,62000,38000,71000,55000,89000,76000], borderColor:'#2874f0', backgroundColor:'rgba(40,116,240,0.1)', tension:0.4, fill:true, borderWidth:2.5, pointBackgroundColor:'#2874f0', pointRadius:4 },
      { label:'Orders', data:[12,18,9,22,15,28,21], borderColor:'#fb641b', backgroundColor:'transparent', tension:0.4, borderWidth:2, borderDash:[5,5], pointBackgroundColor:'#fb641b', pointRadius:4, yAxisID:'y1' }
    ]
  },
  options: {
    responsive:true, maintainAspectRatio:false,
    plugins:{ legend:{ position:'bottom', labels:{ font:{family:'Nunito',size:11} } } },
    scales:{
      y:{ beginAtZero:true, grid:{color:'#f5f5f5'}, ticks:{callback:v=>'₹'+v.toLocaleString('en-IN'), font:{family:'Nunito'}} },
      y1:{ position:'right', beginAtZero:true, grid:{display:false}, ticks:{font:{family:'Nunito'}} },
      x:{ grid:{display:false}, ticks:{font:{family:'Nunito'}} }
    }
  }
});

// Donut Chart
new Chart(document.getElementById('statusChart'), {
  type:'doughnut',
  data:{ labels:['Delivered','Processing','Shipped','Pending','Cancelled'], datasets:[{ data:[68,18,8,4,2], backgroundColor:['#388e3c','#2874f0','#7c3aed','#f57c00','#d32f2f'], borderWidth:0, hoverOffset:4 }] },
  options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ position:'right', labels:{font:{family:'Nunito',size:11}} } } }
});

// Approve/Reject vendor
function approveVendor(id) {
  if(!confirm('Approve this vendor?')) return;
  fetch('ajax/vendor.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:`action=approve&id=${id}`})
    .then(r=>r.json()).then(d=>{ if(d.success) location.reload(); });
}
function rejectVendor(id) {
  if(!confirm('Reject this vendor?')) return;
  fetch('ajax/vendor.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:`action=reject&id=${id}`})
    .then(r=>r.json()).then(d=>{ if(d.success) location.reload(); });
}
</script>
</body>
</html>

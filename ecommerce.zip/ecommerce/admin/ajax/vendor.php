<?php
require_once '../../config.php';
if (!isLoggedIn() || !isAdmin()) { echo json_encode(['success'=>false]); exit; }
header('Content-Type: application/json');
$db     = Database::getInstance()->getConnection();
$action = $_POST['action'] ?? '';
$id     = (int)($_POST['id'] ?? 0);
if (!$id) { echo json_encode(['success'=>false]); exit; }

if ($action === 'approve') {
    $db->query("UPDATE vendors SET status='active' WHERE id=$id");
    echo json_encode(['success'=>true]);
} elseif ($action === 'reject') {
    $db->query("UPDATE vendors SET status='suspended' WHERE id=$id");
    echo json_encode(['success'=>true]);
} elseif ($action === 'approve_product') {
    $db->query("UPDATE products SET approval_status='approved',status='active' WHERE id=$id");
    echo json_encode(['success'=>true]);
} elseif ($action === 'reject_product') {
    $db->query("UPDATE products SET approval_status='rejected' WHERE id=$id");
    echo json_encode(['success'=>true]);
} else {
    echo json_encode(['success'=>false,'message'=>'Invalid action']);
}

<?php
require_once 'config.php';
$db = Database::getInstance()->getConnection();

// Fetch categories
$categories = $db->query("SELECT * FROM categories WHERE status=1 AND parent_id IS NULL ORDER BY sort_order ASC LIMIT 14");

// Fetch featured products
$featured = $db->query("SELECT p.*, v.store_name, v.store_slug FROM products p 
    JOIN vendors v ON p.vendor_id = v.id 
    WHERE p.status='active' AND p.approval_status='approved' AND p.is_featured=1 
    ORDER BY p.created_at DESC LIMIT 10");

// Fetch bestsellers
$bestsellers = $db->query("SELECT p.*, v.store_name FROM products p 
    JOIN vendors v ON p.vendor_id = v.id 
    WHERE p.status='active' AND p.approval_status='approved' 
    ORDER BY p.sold_count DESC LIMIT 10");

// Fetch new arrivals
$new_arrivals = $db->query("SELECT p.*, v.store_name FROM products p 
    JOIN vendors v ON p.vendor_id = v.id 
    WHERE p.status='active' AND p.approval_status='approved' AND p.is_new=1 
    ORDER BY p.created_at DESC LIMIT 10");

// Fetch active vendors
$top_vendors = $db->query("SELECT v.*, u.name FROM vendors v 
    JOIN users u ON v.user_id = u.id 
    WHERE v.status='active' 
    ORDER BY v.total_sales DESC LIMIT 6");

$cart_count = getCartCount();
$page_title = 'ECommerce - India\'s Fastest Growing Marketplace';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($page_title) ?></title>
<meta name="description" content="Shop from millions of products across thousands of vendors. Best prices, fast delivery, easy returns.">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<!-- Swiper -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.css">

<style>
/* ============================================================
   RESET & ROOT
   ============================================================ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --primary: #2874f0;
  --primary-dark: #1a5dc8;
  --primary-light: #e8f0fe;
  --secondary: #fb641b;
  --secondary-light: #fff3ee;
  --accent: #ffd700;
  --success: #388e3c;
  --warning: #f57c00;
  --danger: #d32f2f;
  --text-dark: #212121;
  --text-med: #444;
  --text-light: #878787;
  --text-white: #ffffff;
  --border: #e0e0e0;
  --bg-light: #f1f3f6;
  --bg-white: #ffffff;
  --card-shadow: 0 2px 16px rgba(0,0,0,0.08);
  --card-shadow-hover: 0 8px 32px rgba(40,116,240,0.15);
  --header-h: 112px;
  --radius: 12px;
  --radius-sm: 6px;
  --transition: 0.25s cubic-bezier(0.4,0,0.2,1);
  --font: 'Nunito', sans-serif;
  --font-display: 'Playfair Display', serif;
}
html { scroll-behavior: smooth; }
body {
  font-family: var(--font);
  background: var(--bg-light);
  color: var(--text-dark);
  min-height: 100vh;
  overflow-x: hidden;
}
a { text-decoration: none; color: inherit; }
img { max-width: 100%; display: block; }
ul { list-style: none; }
button, input, select, textarea { font-family: var(--font); }

/* ============================================================
   UTILITY
   ============================================================ */
.container { max-width: 1280px; margin: 0 auto; padding: 0 16px; }
.flex { display: flex; align-items: center; }
.gap-sm { gap: 8px; }
.gap-md { gap: 16px; }
.badge {
  display: inline-flex; align-items: center; justify-content: center;
  background: var(--secondary); color: #fff; border-radius: 50%;
  font-size: 11px; font-weight: 700; min-width: 18px; height: 18px; padding: 0 4px;
}
.section { background: #fff; border-radius: var(--radius); margin: 0 0 16px; box-shadow: var(--card-shadow); overflow: hidden; }
.section-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 20px 24px 0;
  border-bottom: 2px solid var(--bg-light);
  padding-bottom: 14px;
  margin-bottom: 0;
}
.section-title { font-size: 1.25rem; font-weight: 800; color: var(--text-dark); }
.section-title span { color: var(--primary); }
.section-subtitle { font-size: 0.8rem; color: var(--text-light); margin-top: 2px; }
.view-all {
  font-size: 0.85rem; font-weight: 700; color: var(--primary); 
  letter-spacing: 0.5px; text-transform: uppercase;
  padding: 6px 14px; border: 1.5px solid var(--primary); border-radius: 20px;
  transition: var(--transition);
}
.view-all:hover { background: var(--primary); color: #fff; }
.btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 8px;
  padding: 10px 22px; border-radius: 8px; font-weight: 700;
  font-size: 0.9rem; border: none; cursor: pointer; transition: var(--transition);
}
.btn-primary { background: var(--primary); color: #fff; }
.btn-primary:hover { background: var(--primary-dark); transform: translateY(-1px); box-shadow: 0 4px 16px rgba(40,116,240,0.35); }
.btn-secondary { background: var(--secondary); color: #fff; }
.btn-secondary:hover { background: #e5580f; transform: translateY(-1px); }
.btn-outline { background: transparent; color: var(--primary); border: 2px solid var(--primary); }
.btn-outline:hover { background: var(--primary); color: #fff; }

/* ============================================================
   HEADER
   ============================================================ */
.header-top {
  background: var(--primary);
  position: sticky; top: 0; z-index: 1000;
  box-shadow: 0 2px 12px rgba(0,0,0,0.2);
}
.header-inner {
  display: flex; align-items: center; gap: 0; height: 64px;
  max-width: 1280px; margin: 0 auto; padding: 0 16px;
}
.logo {
  font-family: var(--font); font-size: 1.5rem; font-weight: 900;
  color: #fff; letter-spacing: -0.5px; flex-shrink: 0;
  margin-right: 32px;
  display: flex; flex-direction: column;
}
.logo span { font-size: 0.65rem; color: var(--accent); letter-spacing: 0.3px; font-style: italic; font-weight: 600; }
.search-bar {
  flex: 1; display: flex; align-items: center;
  background: #fff; border-radius: 4px; overflow: hidden;
  max-width: 680px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.15);
}
.search-bar input {
  flex: 1; padding: 10px 16px; border: none; outline: none;
  font-size: 0.9rem; color: var(--text-dark); background: transparent;
}
.search-bar button {
  background: #fff; border: none; padding: 0 18px; height: 42px;
  cursor: pointer; color: var(--primary); font-size: 1.1rem;
  transition: var(--transition); border-left: 1px solid var(--border);
}
.search-bar button:hover { background: var(--primary); color: #fff; }
.header-actions { display: flex; align-items: center; gap: 4px; margin-left: auto; }
.header-btn {
  display: flex; flex-direction: column; align-items: center;
  gap: 1px; padding: 6px 14px; border-radius: 4px; cursor: pointer;
  color: #fff; font-size: 0.78rem; font-weight: 600;
  transition: var(--transition); border: none; background: transparent;
  white-space: nowrap;
}
.header-btn:hover { background: rgba(255,255,255,0.15); }
.header-btn i { font-size: 1.1rem; }
.header-btn .label { font-size: 0.72rem; }
.cart-btn { position: relative; }
.cart-badge {
  position: absolute; top: 2px; right: 8px;
  background: var(--accent); color: #000;
  border-radius: 50%; min-width: 16px; height: 16px;
  font-size: 10px; font-weight: 800;
  display: flex; align-items: center; justify-content: center;
}
.seller-btn {
  background: rgba(255,255,255,0.15);
  border: 1.5px solid rgba(255,255,255,0.5);
  border-radius: 4px; padding: 6px 14px;
  color: #fff; font-size: 0.8rem; font-weight: 700;
  cursor: pointer; transition: var(--transition);
}
.seller-btn:hover { background: #fff; color: var(--primary); }

/* Nav Bar */
.header-nav {
  background: var(--primary-dark);
  border-top: 1px solid rgba(255,255,255,0.1);
}
.nav-inner {
  max-width: 1280px; margin: 0 auto; padding: 0 16px;
  display: flex; align-items: center; overflow-x: auto;
  scrollbar-width: none; gap: 0;
}
.nav-inner::-webkit-scrollbar { display: none; }
.nav-item {
  display: flex; flex-direction: column; align-items: center; gap: 3px;
  padding: 8px 16px; color: #fff; font-size: 0.78rem; font-weight: 600;
  cursor: pointer; white-space: nowrap; transition: var(--transition);
  border-bottom: 3px solid transparent; flex-shrink: 0;
}
.nav-item i { font-size: 1.2rem; }
.nav-item:hover { background: rgba(255,255,255,0.1); border-bottom-color: var(--accent); }
.nav-item.active { border-bottom-color: var(--accent); background: rgba(255,255,255,0.1); }

/* ============================================================
   MEGA DROPDOWN
   ============================================================ */
.nav-item { position: relative; }
.mega-menu {
  display: none; position: absolute; top: 100%; left: 0; z-index: 999;
  background: #fff; min-width: 200px; border-radius: 0 0 8px 8px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.15);
  padding: 12px 0; border-top: 3px solid var(--primary);
}
.nav-item:hover .mega-menu { display: block; }
.mega-menu a {
  display: block; padding: 8px 20px; font-size: 0.82rem;
  color: var(--text-dark); transition: var(--transition);
}
.mega-menu a:hover { background: var(--primary-light); color: var(--primary); padding-left: 28px; }

/* ============================================================
   HERO BANNER
   ============================================================ */
.hero { margin: 16px 0 0; }
.hero-grid { display: grid; grid-template-columns: 1fr 280px; gap: 10px; }
.swiper-hero { border-radius: var(--radius); overflow: hidden; }
.hero-slide {
  height: 380px; position: relative; overflow: hidden;
  border-radius: var(--radius);
  background: linear-gradient(135deg, #1a5dc8 0%, #2874f0 50%, #4facfe 100%);
}
.hero-slide img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform 8s ease;
}
.swiper-hero .swiper-slide:hover img { transform: scale(1.05); }
.hero-slide-content {
  position: absolute; bottom: 0; left: 0; right: 0;
  padding: 24px 28px;
  background: linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 100%);
}
.hero-slide-content h2 { font-size: 1.6rem; font-weight: 800; color: #fff; line-height: 1.2; }
.hero-slide-content p { color: rgba(255,255,255,0.85); margin-top: 6px; font-size: 0.9rem; }
.hero-side { display: flex; flex-direction: column; gap: 10px; }
.hero-side-card {
  flex: 1; border-radius: var(--radius); overflow: hidden;
  position: relative; cursor: pointer; min-height: 180px;
  background: linear-gradient(135deg, #ff6b35, #f7c59f);
}
.hero-side-card:nth-child(2) { background: linear-gradient(135deg, #11998e, #38ef7d); }
.hero-side-card img { width: 100%; height: 100%; object-fit: cover; transition: var(--transition); }
.hero-side-card:hover img { transform: scale(1.08); }
.side-card-label {
  position: absolute; bottom: 0; left: 0; right: 0;
  padding: 12px 14px;
  background: linear-gradient(to top, rgba(0,0,0,0.65) 0%, transparent 100%);
  color: #fff; font-weight: 700; font-size: 0.95rem;
}
.swiper-button-next, .swiper-button-prev {
  background: rgba(255,255,255,0.9) !important;
  width: 36px !important; height: 36px !important;
  border-radius: 50% !important; box-shadow: 0 2px 8px rgba(0,0,0,0.2) !important;
}
.swiper-button-next::after, .swiper-button-prev::after {
  font-size: 14px !important; color: var(--primary) !important; font-weight: 800 !important;
}
.swiper-pagination-bullet-active { background: var(--primary) !important; }

/* ============================================================
   FLASH SALE
   ============================================================ */
.flash-section { background: linear-gradient(135deg, #ff416c, #ff4b2b); border-radius: var(--radius); overflow: hidden; }
.flash-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 16px 24px;
}
.flash-title { display: flex; align-items: center; gap: 12px; }
.flash-title h2 { font-size: 1.3rem; font-weight: 900; color: #fff; letter-spacing: -0.3px; }
.flash-title i { font-size: 1.4rem; color: var(--accent); animation: flicker 1.5s infinite; }
@keyframes flicker { 0%,100%{opacity:1;} 50%{opacity:0.5;} }
.countdown { display: flex; align-items: center; gap: 6px; }
.count-item {
  background: rgba(0,0,0,0.3); color: #fff;
  padding: 6px 10px; border-radius: 6px; text-align: center; min-width: 44px;
  backdrop-filter: blur(4px);
}
.count-item .num { font-size: 1.1rem; font-weight: 800; line-height: 1; }
.count-item .label { font-size: 0.6rem; opacity: 0.8; letter-spacing: 0.5px; }
.count-sep { color: #fff; font-size: 1.1rem; font-weight: 800; }
.flash-view-all { color: #fff; font-size: 0.8rem; font-weight: 700; border: 1.5px solid rgba(255,255,255,0.5); padding: 6px 14px; border-radius: 20px; }
.flash-products { padding: 0 16px 16px; }

/* ============================================================
   PRODUCT CARD
   ============================================================ */
.product-card {
  background: #fff; border-radius: var(--radius); overflow: hidden;
  border: 1px solid var(--border); cursor: pointer;
  transition: var(--transition); position: relative;
  display: flex; flex-direction: column;
}
.product-card:hover {
  box-shadow: var(--card-shadow-hover); transform: translateY(-4px);
  border-color: var(--primary);
}
.product-img-wrap {
  position: relative; overflow: hidden; background: #f8f8f8;
  aspect-ratio: 1; display: flex; align-items: center; justify-content: center;
}
.product-img-wrap img {
  width: 100%; height: 100%; object-fit: contain; padding: 8px;
  transition: transform 0.4s ease;
}
.product-card:hover .product-img-wrap img { transform: scale(1.08); }
.product-badge {
  position: absolute; top: 8px; left: 8px;
  background: var(--danger); color: #fff;
  font-size: 0.7rem; font-weight: 800; padding: 3px 8px;
  border-radius: 4px; letter-spacing: 0.3px;
}
.product-badge.new { background: var(--success); }
.product-badge.hot { background: var(--secondary); }
.product-wishlist {
  position: absolute; top: 8px; right: 8px;
  width: 32px; height: 32px; border-radius: 50%;
  background: #fff; display: flex; align-items: center; justify-content: center;
  color: var(--text-light); font-size: 0.9rem; transition: var(--transition);
  box-shadow: 0 2px 8px rgba(0,0,0,0.1); border: none; cursor: pointer;
  opacity: 0;
}
.product-card:hover .product-wishlist { opacity: 1; }
.product-wishlist:hover { color: var(--danger); transform: scale(1.1); }
.product-wishlist.active { color: var(--danger); opacity: 1; }
.product-info { padding: 12px 14px 14px; flex: 1; display: flex; flex-direction: column; gap: 4px; }
.product-vendor { font-size: 0.7rem; color: var(--primary); font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
.product-name { font-size: 0.88rem; color: var(--text-dark); font-weight: 600; line-height: 1.35; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.product-rating { display: flex; align-items: center; gap: 6px; margin-top: 2px; }
.rating-badge { background: var(--success); color: #fff; font-size: 0.7rem; font-weight: 700; padding: 2px 7px; border-radius: 4px; display: flex; align-items: center; gap: 3px; }
.rating-count { font-size: 0.72rem; color: var(--text-light); }
.product-price { display: flex; align-items: center; gap: 8px; margin-top: 4px; flex-wrap: wrap; }
.price-current { font-size: 1.05rem; font-weight: 800; color: var(--text-dark); }
.price-original { font-size: 0.8rem; color: var(--text-light); text-decoration: line-through; }
.price-discount { font-size: 0.8rem; font-weight: 700; color: var(--success); }
.product-actions { display: flex; gap: 8px; padding: 0 14px 14px; margin-top: auto; }
.btn-cart {
  flex: 1; background: var(--primary); color: #fff; border: none;
  padding: 9px 10px; border-radius: 8px; font-size: 0.82rem; font-weight: 700;
  cursor: pointer; transition: var(--transition); display: flex; align-items: center;
  justify-content: center; gap: 6px;
}
.btn-cart:hover { background: var(--primary-dark); }
.btn-buy {
  flex: 1; background: var(--secondary); color: #fff; border: none;
  padding: 9px 10px; border-radius: 8px; font-size: 0.82rem; font-weight: 700;
  cursor: pointer; transition: var(--transition);
}
.btn-buy:hover { background: #e5580f; }

/* ============================================================
   PRODUCT GRID / SWIPER
   ============================================================ */
.products-swiper { padding: 16px 24px 24px !important; }
.products-swiper .swiper-slide { height: auto; }
.swiper-nav-btn {
  width: 36px; height: 36px; border-radius: 50%;
  background: #fff; border: 1.5px solid var(--border);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; transition: var(--transition); color: var(--text-dark);
  box-shadow: var(--card-shadow); font-size: 0.9rem;
}
.swiper-nav-btn:hover { background: var(--primary); color: #fff; border-color: var(--primary); }

/* ============================================================
   CATEGORIES GRID
   ============================================================ */
.categories-grid {
  display: grid; grid-template-columns: repeat(6, 1fr);
  gap: 12px; padding: 20px 24px 24px;
}
.cat-card {
  display: flex; flex-direction: column; align-items: center; gap: 10px;
  padding: 18px 12px; border-radius: var(--radius); background: var(--bg-light);
  cursor: pointer; transition: var(--transition); border: 2px solid transparent;
  text-align: center;
}
.cat-card:hover { background: var(--primary-light); border-color: var(--primary); transform: translateY(-3px); }
.cat-icon {
  width: 56px; height: 56px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.4rem; color: #fff;
  background: linear-gradient(135deg, var(--primary), #4facfe);
  box-shadow: 0 4px 12px rgba(40,116,240,0.3);
}
.cat-card:nth-child(2) .cat-icon { background: linear-gradient(135deg, #f093fb, #f5576c); }
.cat-card:nth-child(3) .cat-icon { background: linear-gradient(135deg, #4facfe, #00f2fe); }
.cat-card:nth-child(4) .cat-icon { background: linear-gradient(135deg, #43e97b, #38f9d7); }
.cat-card:nth-child(5) .cat-icon { background: linear-gradient(135deg, #f7971e, #ffd200); }
.cat-card:nth-child(6) .cat-icon { background: linear-gradient(135deg, #a18cd1, #fbc2eb); }
.cat-card:nth-child(7) .cat-icon { background: linear-gradient(135deg, #fd7043, #ff8a65); }
.cat-card:nth-child(8) .cat-icon { background: linear-gradient(135deg, #26c6da, #00acc1); }
.cat-card:nth-child(9) .cat-icon { background: linear-gradient(135deg, #66bb6a, #4caf50); }
.cat-card:nth-child(10) .cat-icon { background: linear-gradient(135deg, #ef5350, #e53935); }
.cat-card:nth-child(11) .cat-icon { background: linear-gradient(135deg, #ab47bc, #8e24aa); }
.cat-card:nth-child(12) .cat-icon { background: linear-gradient(135deg, #78909c, #546e7a); }
.cat-name { font-size: 0.8rem; font-weight: 700; color: var(--text-dark); line-height: 1.3; }

/* ============================================================
   PROMO BANNERS
   ============================================================ */
.promo-grid {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 12px; margin: 0 0 16px;
}
.promo-card {
  border-radius: var(--radius); overflow: hidden; position: relative;
  height: 160px; cursor: pointer;
  transition: var(--transition);
}
.promo-card:hover { transform: translateY(-4px); box-shadow: 0 8px 32px rgba(0,0,0,0.15); }
.promo-card img { width: 100%; height: 100%; object-fit: cover; }
.promo-content {
  position: absolute; inset: 0;
  display: flex; flex-direction: column; justify-content: center;
  padding: 20px 24px;
}
.promo-content h3 { font-size: 1.2rem; font-weight: 800; color: #fff; line-height: 1.2; }
.promo-content p { font-size: 0.8rem; color: rgba(255,255,255,0.85); margin-top: 4px; }
.promo-content .promo-cta { margin-top: 10px; font-size: 0.8rem; font-weight: 700; color: #fff; border-bottom: 2px solid rgba(255,255,255,0.5); display: inline-block; }
.promo-1 { background: linear-gradient(135deg, #667eea, #764ba2); }
.promo-2 { background: linear-gradient(135deg, #f093fb, #f5576c); }
.promo-3 { background: linear-gradient(135deg, #4facfe, #00f2fe); }

/* ============================================================
   VENDOR CARDS
   ============================================================ */
.vendors-grid {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 16px; padding: 20px 24px 24px;
}
.vendor-card {
  border: 1.5px solid var(--border); border-radius: var(--radius);
  overflow: hidden; cursor: pointer; transition: var(--transition);
}
.vendor-card:hover { border-color: var(--primary); transform: translateY(-3px); box-shadow: var(--card-shadow-hover); }
.vendor-banner { height: 90px; background: linear-gradient(135deg, var(--primary), #4facfe); position: relative; overflow: hidden; }
.vendor-banner img { width: 100%; height: 100%; object-fit: cover; }
.vendor-info { padding: 12px 16px 16px; }
.vendor-logo {
  width: 52px; height: 52px; border-radius: 10px;
  background: #fff; border: 2px solid var(--border);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.4rem; color: var(--primary);
  margin: -26px 0 8px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}
.vendor-name { font-size: 0.95rem; font-weight: 800; color: var(--text-dark); }
.vendor-meta { font-size: 0.75rem; color: var(--text-light); margin-top: 3px; }
.vendor-stats { display: flex; gap: 16px; margin-top: 10px; }
.vendor-stat { text-align: center; }
.vendor-stat .num { font-size: 0.88rem; font-weight: 800; color: var(--primary); }
.vendor-stat .lbl { font-size: 0.68rem; color: var(--text-light); }
.vendor-rating { display: flex; align-items: center; gap: 4px; margin-top: 6px; }
.stars { color: var(--warning); font-size: 0.75rem; }

/* ============================================================
   FEATURES BAR
   ============================================================ */
.features-bar {
  background: #fff; border-radius: var(--radius);
  display: grid; grid-template-columns: repeat(4, 1fr);
  gap: 0; margin: 0 0 16px; box-shadow: var(--card-shadow);
  overflow: hidden;
}
.feature-item {
  display: flex; align-items: center; gap: 14px;
  padding: 20px 24px; border-right: 1px solid var(--border);
}
.feature-item:last-child { border-right: none; }
.feature-icon {
  width: 48px; height: 48px; border-radius: 12px;
  background: var(--primary-light); color: var(--primary);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.3rem; flex-shrink: 0;
}
.feature-text h4 { font-size: 0.88rem; font-weight: 800; color: var(--text-dark); }
.feature-text p { font-size: 0.75rem; color: var(--text-light); margin-top: 2px; }

/* ============================================================
   NEWSLETTER
   ============================================================ */
.newsletter {
  background: linear-gradient(135deg, var(--primary) 0%, #4facfe 100%);
  border-radius: var(--radius); padding: 40px 40px;
  margin: 0 0 16px; text-align: center;
  position: relative; overflow: hidden;
}
.newsletter::before {
  content: ''; position: absolute; width: 300px; height: 300px;
  background: rgba(255,255,255,0.05); border-radius: 50%;
  top: -100px; right: -80px;
}
.newsletter h2 { font-size: 1.6rem; font-weight: 900; color: #fff; }
.newsletter p { color: rgba(255,255,255,0.85); margin-top: 8px; font-size: 0.95rem; }
.newsletter-form { display: flex; gap: 10px; max-width: 480px; margin: 20px auto 0; }
.newsletter-form input {
  flex: 1; padding: 12px 18px; border-radius: 8px; border: none;
  font-size: 0.9rem; outline: none;
}
.newsletter-form button {
  background: var(--secondary); color: #fff; border: none;
  padding: 12px 24px; border-radius: 8px; font-weight: 700; cursor: pointer;
  transition: var(--transition); font-size: 0.9rem;
}
.newsletter-form button:hover { background: #e5580f; }

/* ============================================================
   FOOTER
   ============================================================ */
.footer { background: #172337; color: rgba(255,255,255,0.7); margin-top: 0; }
.footer-top {
  display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 1fr;
  gap: 32px; padding: 48px 0 32px; border-bottom: 1px solid rgba(255,255,255,0.08);
}
.footer-brand .logo-f { font-size: 1.6rem; font-weight: 900; color: #fff; }
.footer-brand p { margin-top: 12px; font-size: 0.82rem; line-height: 1.7; max-width: 260px; }
.footer-social { display: flex; gap: 10px; margin-top: 16px; }
.social-icon {
  width: 36px; height: 36px; border-radius: 8px;
  background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.7);
  display: flex; align-items: center; justify-content: center;
  font-size: 0.9rem; transition: var(--transition); cursor: pointer;
}
.social-icon:hover { background: var(--primary); color: #fff; }
.footer-col h4 { font-size: 0.85rem; font-weight: 800; color: #fff; letter-spacing: 0.5px; text-transform: uppercase; margin-bottom: 16px; }
.footer-col a {
  display: block; font-size: 0.82rem; color: rgba(255,255,255,0.6);
  margin-bottom: 10px; transition: var(--transition);
}
.footer-col a:hover { color: #fff; padding-left: 4px; }
.footer-bottom {
  padding: 20px 0; display: flex; align-items: center;
  justify-content: space-between; flex-wrap: wrap; gap: 12px;
}
.footer-bottom p { font-size: 0.78rem; color: rgba(255,255,255,0.4); }
.payment-icons { display: flex; gap: 8px; align-items: center; }
.payment-icon {
  background: rgba(255,255,255,0.08); padding: 5px 10px;
  border-radius: 4px; font-size: 0.7rem; color: rgba(255,255,255,0.5);
  font-weight: 700; letter-spacing: 0.5px;
}

/* ============================================================
   CART DRAWER
   ============================================================ */
.cart-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.5);
  z-index: 9000; opacity: 0; visibility: hidden; transition: var(--transition);
}
.cart-overlay.open { opacity: 1; visibility: visible; }
.cart-drawer {
  position: fixed; top: 0; right: 0; bottom: 0; width: 400px;
  background: #fff; z-index: 9001; transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.4,0,0.2,1);
  display: flex; flex-direction: column; box-shadow: -4px 0 32px rgba(0,0,0,0.15);
}
.cart-drawer.open { transform: translateX(0); }
.cart-drawer-header {
  padding: 20px 24px; border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between;
}
.cart-drawer-header h3 { font-size: 1.1rem; font-weight: 800; }
.close-btn { background: none; border: none; font-size: 1.2rem; cursor: pointer; color: var(--text-light); padding: 4px; }
.cart-drawer-body { flex: 1; overflow-y: auto; padding: 16px 24px; }
.cart-empty { text-align: center; padding: 60px 20px; }
.cart-empty i { font-size: 3rem; color: var(--text-light); margin-bottom: 16px; }
.cart-empty p { color: var(--text-light); }
.cart-item { display: flex; gap: 12px; padding: 16px 0; border-bottom: 1px solid var(--border); }
.cart-item-img { width: 72px; height: 72px; border-radius: 8px; object-fit: contain; background: #f8f8f8; padding: 4px; flex-shrink: 0; }
.cart-item-info { flex: 1; }
.cart-item-name { font-size: 0.85rem; font-weight: 600; line-height: 1.3; }
.cart-item-price { font-weight: 800; color: var(--primary); font-size: 0.95rem; margin-top: 4px; }
.cart-item-qty {
  display: flex; align-items: center; gap: 10px; margin-top: 8px;
}
.qty-btn {
  width: 26px; height: 26px; border-radius: 4px; background: var(--bg-light);
  border: 1px solid var(--border); cursor: pointer; font-size: 0.9rem;
  display: flex; align-items: center; justify-content: center; transition: var(--transition);
}
.qty-btn:hover { background: var(--primary); color: #fff; border-color: var(--primary); }
.qty-num { font-size: 0.88rem; font-weight: 700; min-width: 20px; text-align: center; }
.cart-remove { background: none; border: none; color: var(--text-light); cursor: pointer; font-size: 0.8rem; margin-left: auto; transition: var(--transition); align-self: flex-start; margin-top: 4px; }
.cart-remove:hover { color: var(--danger); }
.cart-drawer-footer { padding: 16px 24px; border-top: 1px solid var(--border); }
.cart-total { display: flex; justify-content: space-between; font-weight: 800; font-size: 1rem; margin-bottom: 12px; }
.cart-total .amount { color: var(--primary); font-size: 1.1rem; }

/* ============================================================
   TOAST NOTIFICATION
   ============================================================ */
.toast-container { position: fixed; top: 80px; right: 16px; z-index: 9999; display: flex; flex-direction: column; gap: 10px; }
.toast {
  background: #fff; border-radius: 10px; padding: 14px 18px;
  display: flex; align-items: center; gap: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.15); min-width: 280px;
  transform: translateX(120%); transition: transform 0.3s cubic-bezier(0.4,0,0.2,1);
  border-left: 4px solid var(--success);
}
.toast.show { transform: translateX(0); }
.toast.error { border-left-color: var(--danger); }
.toast.warning { border-left-color: var(--warning); }
.toast-icon { font-size: 1.2rem; }
.toast.success .toast-icon { color: var(--success); }
.toast.error .toast-icon { color: var(--danger); }
.toast-msg { font-size: 0.85rem; font-weight: 600; flex: 1; }

/* ============================================================
   MOBILE NAV
   ============================================================ */
.mobile-nav {
  display: none; position: fixed; bottom: 0; left: 0; right: 0;
  background: #fff; border-top: 1px solid var(--border);
  z-index: 900; padding: 8px 0;
  box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
}
.mobile-nav ul {
  display: flex; justify-content: space-around;
}
.mobile-nav-item {
  display: flex; flex-direction: column; align-items: center; gap: 3px;
  padding: 4px 12px; cursor: pointer; color: var(--text-light);
  font-size: 0.68rem; font-weight: 700; transition: var(--transition);
  position: relative;
}
.mobile-nav-item i { font-size: 1.2rem; }
.mobile-nav-item.active, .mobile-nav-item:hover { color: var(--primary); }

/* ============================================================
   SCROLL TO TOP
   ============================================================ */
.scroll-top {
  position: fixed; bottom: 80px; right: 20px;
  width: 44px; height: 44px; border-radius: 50%;
  background: var(--primary); color: #fff;
  display: flex; align-items: center; justify-content: center;
  font-size: 1rem; cursor: pointer; z-index: 800;
  box-shadow: 0 4px 16px rgba(40,116,240,0.4);
  opacity: 0; transform: translateY(20px);
  transition: var(--transition); border: none;
}
.scroll-top.show { opacity: 1; transform: translateY(0); }
.scroll-top:hover { background: var(--primary-dark); transform: translateY(-2px); }

/* ============================================================
   LOADING SKELETON
   ============================================================ */
.skeleton { background: linear-gradient(90deg, #f0f0f0 25%, #e8e8e8 50%, #f0f0f0 75%); background-size: 200% 100%; animation: shimmer 1.5s infinite; border-radius: 8px; }
@keyframes shimmer { 0%{background-position:200% 0;} 100%{background-position:-200% 0;} }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1024px) {
  .hero-grid { grid-template-columns: 1fr; }
  .hero-side { flex-direction: row; }
  .hero-side-card { min-height: 120px; }
  .categories-grid { grid-template-columns: repeat(4, 1fr); }
  .footer-top { grid-template-columns: 1fr 1fr; }
  .features-bar { grid-template-columns: repeat(2, 1fr); }
  .vendors-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 768px) {
  .header-inner { height: 56px; gap: 8px; }
  .logo { font-size: 1.2rem; margin-right: 12px; }
  .logo span { display: none; }
  .header-nav { display: none; }
  .search-bar { max-width: none; }
  .header-btn .label { display: none; }
  .seller-btn { display: none; }
  .hero-slide { height: 220px; }
  .hero-side { display: none; }
  .categories-grid { grid-template-columns: repeat(3, 1fr); gap: 8px; padding: 12px; }
  .cat-icon { width: 44px; height: 44px; font-size: 1.1rem; }
  .promo-grid { grid-template-columns: 1fr; }
  .features-bar { grid-template-columns: repeat(2, 1fr); }
  .vendors-grid { grid-template-columns: 1fr; }
  .footer-top { grid-template-columns: 1fr 1fr; gap: 24px; }
  .newsletter { padding: 24px 20px; }
  .newsletter-form { flex-direction: column; }
  .mobile-nav { display: block; }
  body { padding-bottom: 64px; }
  .cart-drawer { width: 100%; }
  .section-header { padding: 14px 16px 12px; }
  .products-swiper { padding: 12px 16px 20px !important; }
}
@media (max-width: 480px) {
  .categories-grid { grid-template-columns: repeat(3, 1fr); }
  .footer-top { grid-template-columns: 1fr; }
  .flash-header { flex-wrap: wrap; gap: 10px; }
}
</style>
</head>
<body>

<!-- ============================================================
   HEADER
   ============================================================ -->
<header>
  <div class="header-top">
    <div class="header-inner">
      <a href="index.php" class="logo">
        <span style="font-size:1.5rem; font-weight:900;">🛒 ECommerce</span>
        <span>Explore Plus ✦</span>
      </a>

      <div class="search-bar">
        <input type="text" id="searchInput" placeholder="Search for Products, Brands and More" autocomplete="off">
        <button onclick="doSearch()"><i class="fas fa-search"></i></button>
      </div>

      <div class="header-actions">
        <a href="login.php" class="header-btn">
          <i class="fas fa-user-circle"></i>
          <span class="label"><?= isLoggedIn() ? htmlspecialchars($_SESSION['user_name'] ?? 'Account') : 'Login' ?></span>
        </a>
        <a href="wishlist.php" class="header-btn">
          <i class="fas fa-heart"></i>
          <span class="label">Wishlist</span>
        </a>
        <button class="header-btn cart-btn" onclick="toggleCart()">
          <i class="fas fa-shopping-cart"></i>
          <span class="label">Cart</span>
          <span class="cart-badge" id="cartBadge"><?= $cart_count ?></span>
        </button>
        <a href="vendor/register.php" class="seller-btn">
          <i class="fas fa-store"></i> Become a Seller
        </a>
      </div>
    </div>
  </div>

  <!-- Category Nav -->
  <nav class="header-nav">
    <div class="nav-inner">
      <div class="nav-item active" onclick="location.href='index.php'">
        <i class="fas fa-star"></i>
        <span>For You</span>
      </div>
      <?php if ($categories): $categories->data_seek(0); while ($cat = $categories->fetch_assoc()): ?>
      <div class="nav-item" onclick="location.href='category.php?slug=<?= urlencode($cat['slug']) ?>'">
        <i class="<?= htmlspecialchars($cat['icon'] ?? 'fas fa-tag') ?>"></i>
        <span><?= htmlspecialchars($cat['name']) ?></span>
      </div>
      <?php endwhile; endif; ?>
    </div>
  </nav>
</header>

<!-- ============================================================
   MAIN CONTENT
   ============================================================ -->
<main>
<div class="container">

<!-- HERO SECTION -->
<div class="hero">
  <div class="hero-grid">
    <div class="swiper swiper-hero">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="hero-slide" style="background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);">
            <div class="hero-slide-content">
              <h2>🔥 Biggest Sale of the Year</h2>
              <p>Up to 80% off on electronics, fashion & more</p>
              <a href="sale.php" class="btn btn-primary" style="margin-top:12px; display:inline-flex;">Shop Now <i class="fas fa-arrow-right"></i></a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="hero-slide" style="background: linear-gradient(135deg, #11998e, #38ef7d);">
            <div class="hero-slide-content">
              <h2>🛋️ Transform Your Home</h2>
              <p>Premium furniture at unbeatable prices</p>
              <a href="category.php?slug=furniture" class="btn btn-secondary" style="margin-top:12px; display:inline-flex;">Explore <i class="fas fa-arrow-right"></i></a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="hero-slide" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
            <div class="hero-slide-content">
              <h2>👗 New Fashion Arrivals</h2>
              <p>Trending styles, fresh looks every day</p>
              <a href="category.php?slug=fashion" class="btn btn-outline" style="margin-top:12px; display:inline-flex; border-color:#fff; color:#fff;">View Collection</a>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="hero-slide" style="background: linear-gradient(135deg, #4facfe, #00f2fe);">
            <div class="hero-slide-content">
              <h2>📱 Latest Smartphones</h2>
              <p>Best deals on top brands with EMI options</p>
              <a href="category.php?slug=mobiles" class="btn btn-primary" style="margin-top:12px; display:inline-flex;">Shop Mobiles</a>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-pagination"></div>
    </div>
    <div class="hero-side">
      <div class="hero-side-card" onclick="location.href='category.php?slug=fashion'">
        <div class="side-card-label">👗 Fashion Up to 70% Off</div>
      </div>
      <div class="hero-side-card" onclick="location.href='category.php?slug=electronics'">
        <div class="side-card-label">⚡ Electronics Deals</div>
      </div>
    </div>
  </div>
</div>

<!-- FEATURES BAR -->
<div class="features-bar" style="margin-top:16px;">
  <div class="feature-item">
    <div class="feature-icon"><i class="fas fa-shipping-fast"></i></div>
    <div class="feature-text"><h4>Free Delivery</h4><p>On orders above ₹499</p></div>
  </div>
  <div class="feature-item">
    <div class="feature-icon"><i class="fas fa-shield-alt"></i></div>
    <div class="feature-text"><h4>Secure Payment</h4><p>100% secure transactions</p></div>
  </div>
  <div class="feature-item">
    <div class="feature-icon"><i class="fas fa-undo-alt"></i></div>
    <div class="feature-text"><h4>Easy Returns</h4><p>7-day hassle-free returns</p></div>
  </div>
  <div class="feature-item">
    <div class="feature-icon"><i class="fas fa-headset"></i></div>
    <div class="feature-text"><h4>24/7 Support</h4><p>Dedicated customer care</p></div>
  </div>
</div>

<!-- CATEGORIES -->
<div class="section" style="margin-top:16px;">
  <div class="section-header">
    <div>
      <div class="section-title">Shop by <span>Category</span></div>
      <div class="section-subtitle">Browse through our wide range of categories</div>
    </div>
    <a href="categories.php" class="view-all">View All</a>
  </div>
  <div class="categories-grid">
    <?php if ($categories): $categories->data_seek(0); while ($cat = $categories->fetch_assoc()): ?>
    <div class="cat-card" onclick="location.href='category.php?slug=<?= urlencode($cat['slug']) ?>'">
      <div class="cat-icon"><i class="<?= htmlspecialchars($cat['icon'] ?? 'fas fa-tag') ?>"></i></div>
      <div class="cat-name"><?= htmlspecialchars($cat['name']) ?></div>
    </div>
    <?php endwhile; else: ?>
    <?php
    $def_cats = [
      ['fas fa-tshirt','Fashion'],['fas fa-mobile-alt','Mobiles'],
      ['fas fa-laptop','Electronics'],['fas fa-spa','Beauty'],
      ['fas fa-home','Home & Living'],['fas fa-blender','Appliances'],
      ['fas fa-couch','Furniture'],['fas fa-futbol','Sports'],
      ['fas fa-book','Books'],['fas fa-heartbeat','Food & Health'],
      ['fas fa-baby','Toys & Baby'],['fas fa-car','Auto Accessories'],
    ];
    foreach($def_cats as $c): ?>
    <div class="cat-card" onclick="location.href='category.php'">
      <div class="cat-icon"><i class="<?= $c[0] ?>"></i></div>
      <div class="cat-name"><?= $c[1] ?></div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- FLASH SALE -->
<div class="flash-section section">
  <div class="flash-header">
    <div class="flash-title">
      <i class="fas fa-bolt"></i>
      <div>
        <h2>Flash Sale</h2>
        <div style="font-size:0.75rem;color:rgba(255,255,255,0.7);">Limited time deals!</div>
      </div>
    </div>
    <div class="countdown" id="countdown">
      <div class="count-item"><div class="num" id="cHours">00</div><div class="label">HRS</div></div>
      <div class="count-sep">:</div>
      <div class="count-item"><div class="num" id="cMins">00</div><div class="label">MIN</div></div>
      <div class="count-sep">:</div>
      <div class="count-item"><div class="num" id="cSecs">00</div><div class="label">SEC</div></div>
    </div>
    <a href="flash-sale.php" class="flash-view-all">View All →</a>
  </div>
  <div class="flash-products">
    <div class="swiper swiper-flash">
      <div class="swiper-wrapper" id="flashProducts">
        <!-- Loaded via AJAX or shown as placeholder -->
        <?php
        $flash_items = [
          ['Wireless Earbuds Pro Max', '₹1,299', '₹4,999', '74%'],
          ['Smart Watch Series 5', '₹2,499', '₹8,999', '72%'],
          ['Gaming Mouse RGB', '₹799', '₹2,499', '68%'],
          ['Bluetooth Speaker', '₹999', '₹3,499', '71%'],
          ['USB-C Hub 7-in-1', '₹549', '₹1,999', '72%'],
          ['Power Bank 20000mAh', '₹899', '₹2,999', '70%'],
        ];
        foreach($flash_items as $item): ?>
        <div class="swiper-slide" style="width:180px;">
          <div class="product-card">
            <div class="product-img-wrap">
              <div style="width:100%;aspect-ratio:1;background:linear-gradient(135deg,#f0f4ff,#e8f0fe);display:flex;align-items:center;justify-content:center;">
                <i class="fas fa-box" style="font-size:2.5rem;color:var(--primary);opacity:0.3;"></i>
              </div>
              <div class="product-badge"><?= $item[3] ?> OFF</div>
            </div>
            <div class="product-info">
              <div class="product-name"><?= $item[0] ?></div>
              <div class="product-price">
                <span class="price-current"><?= $item[1] ?></span>
                <span class="price-original"><?= $item[2] ?></span>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- PROMO BANNERS -->
<div class="promo-grid">
  <div class="promo-card promo-1" onclick="location.href='category.php?slug=electronics'">
    <div class="promo-content">
      <h3>Electronics Bonanza</h3>
      <p>Up to 60% off on gadgets</p>
      <span class="promo-cta">Shop Now →</span>
    </div>
  </div>
  <div class="promo-card promo-2" onclick="location.href='category.php?slug=fashion'">
    <div class="promo-content">
      <h3>Fashion Week</h3>
      <p>New arrivals every day</p>
      <span class="promo-cta">Explore →</span>
    </div>
  </div>
  <div class="promo-card promo-3" onclick="location.href='category.php?slug=home-living'">
    <div class="promo-content">
      <h3>Home Makeover</h3>
      <p>Premium furniture & decor</p>
      <span class="promo-cta">Discover →</span>
    </div>
  </div>
</div>

<!-- FEATURED PRODUCTS -->
<div class="section">
  <div class="section-header">
    <div>
      <div class="section-title">Featured <span>Products</span></div>
      <div class="section-subtitle">Handpicked products just for you</div>
    </div>
    <div style="display:flex;align-items:center;gap:12px;">
      <button class="swiper-nav-btn" id="featPrev"><i class="fas fa-chevron-left"></i></button>
      <button class="swiper-nav-btn" id="featNext"><i class="fas fa-chevron-right"></i></button>
      <a href="products.php?featured=1" class="view-all">View All</a>
    </div>
  </div>
  <div class="swiper swiper-featured products-swiper">
    <div class="swiper-wrapper">
      <?php if ($featured && $featured->num_rows > 0): while ($p = $featured->fetch_assoc()): ?>
      <div class="swiper-slide">
        <?= renderProductCard($p) ?>
      </div>
      <?php endwhile; else: ?>
      <?php for($i=0;$i<8;$i++): echo renderDemoCard($i); endfor; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- BESTSELLERS -->
<div class="section">
  <div class="section-header">
    <div>
      <div class="section-title">🏆 Best <span>Sellers</span></div>
      <div class="section-subtitle">Most loved products by our customers</div>
    </div>
    <div style="display:flex;align-items:center;gap:12px;">
      <button class="swiper-nav-btn" id="bestPrev"><i class="fas fa-chevron-left"></i></button>
      <button class="swiper-nav-btn" id="bestNext"><i class="fas fa-chevron-right"></i></button>
      <a href="products.php?sort=bestseller" class="view-all">View All</a>
    </div>
  </div>
  <div class="swiper swiper-best products-swiper">
    <div class="swiper-wrapper">
      <?php if ($bestsellers && $bestsellers->num_rows > 0): while ($p = $bestsellers->fetch_assoc()): ?>
      <div class="swiper-slide"><?= renderProductCard($p) ?></div>
      <?php endwhile; else: ?>
      <?php for($i=0;$i<8;$i++): echo renderDemoCard($i+8); endfor; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- NEW ARRIVALS -->
<div class="section">
  <div class="section-header">
    <div>
      <div class="section-title">✨ New <span>Arrivals</span></div>
      <div class="section-subtitle">Fresh products added this week</div>
    </div>
    <div style="display:flex;align-items:center;gap:12px;">
      <button class="swiper-nav-btn" id="newPrev"><i class="fas fa-chevron-left"></i></button>
      <button class="swiper-nav-btn" id="newNext"><i class="fas fa-chevron-right"></i></button>
      <a href="products.php?sort=new" class="view-all">View All</a>
    </div>
  </div>
  <div class="swiper swiper-new products-swiper">
    <div class="swiper-wrapper">
      <?php if ($new_arrivals && $new_arrivals->num_rows > 0): while ($p = $new_arrivals->fetch_assoc()): ?>
      <div class="swiper-slide"><?= renderProductCard($p) ?></div>
      <?php endwhile; else: ?>
      <?php for($i=0;$i<8;$i++): echo renderDemoCard($i+16); endfor; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- TOP VENDORS -->
<div class="section">
  <div class="section-header">
    <div>
      <div class="section-title">🏪 Our Top <span>Sellers</span></div>
      <div class="section-subtitle">Trusted vendors with verified ratings</div>
    </div>
    <a href="vendors.php" class="view-all">View All</a>
  </div>
  <div class="vendors-grid">
    <?php if ($top_vendors && $top_vendors->num_rows > 0): while ($v = $top_vendors->fetch_assoc()): ?>
    <div class="vendor-card" onclick="location.href='store/<?= urlencode($v['store_slug']) ?>'">
      <div class="vendor-banner"></div>
      <div class="vendor-info">
        <div class="vendor-logo"><i class="fas fa-store"></i></div>
        <div class="vendor-name"><?= htmlspecialchars($v['store_name']) ?></div>
        <div class="vendor-meta"><?= $v['tier'] === 'premium' ? '⭐ Premium Seller' : 'Verified Seller' ?></div>
        <div class="vendor-stats">
          <div class="vendor-stat"><div class="num"><?= number_format($v['total_orders']) ?></div><div class="lbl">Orders</div></div>
          <div class="vendor-stat"><div class="num">₹<?= number_format($v['total_sales']/1000,1) ?>K</div><div class="lbl">Sales</div></div>
          <div class="vendor-stat"><div class="num"><?= $v['rating'] > 0 ? number_format($v['rating'],1) : '4.5' ?>★</div><div class="lbl">Rating</div></div>
        </div>
      </div>
    </div>
    <?php endwhile; else: ?>
    <?php for($i=0;$i<6;$i++): ?>
    <div class="vendor-card" onclick="location.href='vendors.php'">
      <div class="vendor-banner" style="background: linear-gradient(135deg, hsl(<?= $i*40 ?>,70%,45%), hsl(<?= $i*40+30 ?>,70%,60%));"></div>
      <div class="vendor-info">
        <div class="vendor-logo"><i class="fas fa-store"></i></div>
        <div class="vendor-name">Top Seller <?= $i+1 ?></div>
        <div class="vendor-meta">⭐ Premium Seller</div>
        <div class="vendor-stats">
          <div class="vendor-stat"><div class="num"><?= rand(100,999) ?></div><div class="lbl">Orders</div></div>
          <div class="vendor-stat"><div class="num">₹<?= rand(10,99) ?>K</div><div class="lbl">Sales</div></div>
          <div class="vendor-stat"><div class="num">4.<?= rand(5,9) ?>★</div><div class="lbl">Rating</div></div>
        </div>
      </div>
    </div>
    <?php endfor; endif; ?>
  </div>
</div>

<!-- BECOME A SELLER CTA -->
<div style="background: linear-gradient(135deg, #172337, #1a3a5c); border-radius: var(--radius); padding: 40px 40px; margin: 0 0 16px; display:grid; grid-template-columns:1fr auto; align-items:center; gap:32px;">
  <div>
    <div style="font-size:0.85rem;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">📈 Grow Your Business</div>
    <h2 style="font-size:1.8rem;font-weight:900;color:#fff;line-height:1.2;">Start Selling on ECommerce</h2>
    <p style="color:rgba(255,255,255,0.6);margin-top:10px;max-width:500px;line-height:1.7;">Join thousands of vendors already earning with us. Easy onboarding, powerful dashboard, instant payouts.</p>
    <div style="display:flex;gap:12px;margin-top:20px;flex-wrap:wrap;">
      <div style="display:flex;align-items:center;gap:8px;color:rgba(255,255,255,0.7);font-size:0.82rem;"><i class="fas fa-check-circle" style="color:var(--accent);"></i> Free Registration</div>
      <div style="display:flex;align-items:center;gap:8px;color:rgba(255,255,255,0.7);font-size:0.82rem;"><i class="fas fa-check-circle" style="color:var(--accent);"></i> Low Commission</div>
      <div style="display:flex;align-items:center;gap:8px;color:rgba(255,255,255,0.7);font-size:0.82rem;"><i class="fas fa-check-circle" style="color:var(--accent);"></i> Weekly Payouts</div>
      <div style="display:flex;align-items:center;gap:8px;color:rgba(255,255,255,0.7);font-size:0.82rem;"><i class="fas fa-check-circle" style="color:var(--accent);"></i> 24/7 Support</div>
    </div>
  </div>
  <a href="vendor/register.php" class="btn btn-secondary" style="font-size:1rem;padding:14px 32px;white-space:nowrap;">Start Selling <i class="fas fa-arrow-right"></i></a>
</div>

<!-- NEWSLETTER -->
<div class="newsletter">
  <h2>📧 Get Exclusive Deals in Your Inbox</h2>
  <p>Subscribe to our newsletter for special discounts, new arrivals & flash sale alerts</p>
  <div class="newsletter-form">
    <input type="email" id="nlEmail" placeholder="Enter your email address">
    <button onclick="subscribeNewsletter()"><i class="fas fa-paper-plane"></i> Subscribe</button>
  </div>
</div>

</div><!-- /container -->
</main>

<!-- ============================================================
   CART DRAWER
   ============================================================ -->
<div class="cart-overlay" id="cartOverlay" onclick="toggleCart()"></div>
<div class="cart-drawer" id="cartDrawer">
  <div class="cart-drawer-header">
    <h3>🛒 My Cart (<span id="cartItemCount">0</span>)</h3>
    <button class="close-btn" onclick="toggleCart()"><i class="fas fa-times"></i></button>
  </div>
  <div class="cart-drawer-body" id="cartBody">
    <div class="cart-empty">
      <i class="fas fa-shopping-cart"></i>
      <p>Your cart is empty</p>
      <a href="products.php" class="btn btn-primary" style="margin-top:16px;">Start Shopping</a>
    </div>
  </div>
  <div class="cart-drawer-footer" id="cartFooter" style="display:none;">
    <div class="cart-total">
      <span>Total Amount</span>
      <span class="amount" id="cartTotal">₹0</span>
    </div>
    <a href="cart.php" class="btn btn-outline" style="width:100%;margin-bottom:10px;">View Cart</a>
    <a href="checkout.php" class="btn btn-primary" style="width:100%;">Proceed to Checkout <i class="fas fa-arrow-right"></i></a>
  </div>
</div>

<!-- TOAST CONTAINER -->
<div class="toast-container" id="toastContainer"></div>

<!-- SCROLL TO TOP -->
<button class="scroll-top" id="scrollTop" onclick="window.scrollTo({top:0,behavior:'smooth'})">
  <i class="fas fa-chevron-up"></i>
</button>

<!-- MOBILE BOTTOM NAV -->
<nav class="mobile-nav">
  <ul>
    <li class="mobile-nav-item active" onclick="location.href='index.php'"><i class="fas fa-home"></i><span>Home</span></li>
    <li class="mobile-nav-item" onclick="location.href='categories.php'"><i class="fas fa-th-large"></i><span>Categories</span></li>
    <li class="mobile-nav-item" onclick="location.href='search.php'"><i class="fas fa-search"></i><span>Search</span></li>
    <li class="mobile-nav-item" onclick="toggleCart()"><i class="fas fa-shopping-cart"></i><span>Cart</span></li>
    <li class="mobile-nav-item" onclick="location.href='account.php'"><i class="fas fa-user"></i><span>Account</span></li>
  </ul>
</nav>

<!-- SCRIPTS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.js"></script>
<script>
// ============================================================
// SWIPERS
// ============================================================
const heroSwiper = new Swiper('.swiper-hero', {
  loop: true, autoplay: { delay: 4000, disableOnInteraction: false },
  pagination: { el: '.swiper-pagination', clickable: true },
  navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
  effect: 'fade', fadeEffect: { crossFade: true },
});

const flashSwiper = new Swiper('.swiper-flash', {
  slidesPerView: 'auto', spaceBetween: 12, freeMode: true,
});

const makeSwiper = (cls, prevId, nextId) => new Swiper(cls, {
  slidesPerView: 2, spaceBetween: 12,
  navigation: { nextEl: '#'+nextId, prevEl: '#'+prevId },
  breakpoints: {
    480: { slidesPerView: 2 }, 640: { slidesPerView: 3 },
    900: { slidesPerView: 4 }, 1200: { slidesPerView: 5 }
  }
});

makeSwiper('.swiper-featured','featPrev','featNext');
makeSwiper('.swiper-best','bestPrev','bestNext');
makeSwiper('.swiper-new','newPrev','newNext');

// ============================================================
// COUNTDOWN TIMER
// ============================================================
(function countdown() {
  const end = new Date();
  end.setHours(end.getHours() + 8);
  setInterval(() => {
    const now = new Date(), diff = end - now;
    if(diff <= 0) return;
    const h = Math.floor(diff/3600000);
    const m = Math.floor((diff%3600000)/60000);
    const s = Math.floor((diff%60000)/1000);
    document.getElementById('cHours').textContent = String(h).padStart(2,'0');
    document.getElementById('cMins').textContent  = String(m).padStart(2,'0');
    document.getElementById('cSecs').textContent  = String(s).padStart(2,'0');
  }, 1000);
})();

// ============================================================
// CART
// ============================================================
let cartData = [];

function toggleCart() {
  const overlay = document.getElementById('cartOverlay');
  const drawer  = document.getElementById('cartDrawer');
  overlay.classList.toggle('open');
  drawer.classList.toggle('open');
  if(drawer.classList.contains('open')) loadCart();
}

function loadCart() {
  fetch('ajax/cart.php?action=get')
    .then(r => r.json())
    .then(data => { cartData = data.items || []; renderCart(); })
    .catch(() => renderCart());
}

function renderCart() {
  const body   = document.getElementById('cartBody');
  const footer = document.getElementById('cartFooter');
  const count  = document.getElementById('cartItemCount');
  const badge  = document.getElementById('cartBadge');

  if(!cartData.length) {
    body.innerHTML = `<div class="cart-empty"><i class="fas fa-shopping-cart"></i><p>Your cart is empty</p><a href="products.php" class="btn btn-primary" style="margin-top:16px;">Start Shopping</a></div>`;
    footer.style.display = 'none';
    count.textContent = '0'; badge.textContent = '0';
    return;
  }

  let total = 0, html = '';
  cartData.forEach(item => {
    total += item.price * item.qty;
    html += `<div class="cart-item">
      <img class="cart-item-img" src="${item.image || 'assets/img/placeholder.png'}" alt="${item.name}">
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">₹${(item.price*item.qty).toLocaleString('en-IN')}</div>
        <div class="cart-item-qty">
          <button class="qty-btn" onclick="updateCart(${item.id},'decrease')"><i class="fas fa-minus"></i></button>
          <span class="qty-num">${item.qty}</span>
          <button class="qty-btn" onclick="updateCart(${item.id},'increase')"><i class="fas fa-plus"></i></button>
        </div>
      </div>
      <button class="cart-remove" onclick="removeFromCart(${item.id})"><i class="fas fa-trash"></i></button>
    </div>`;
  });

  body.innerHTML = html;
  document.getElementById('cartTotal').textContent = '₹' + total.toLocaleString('en-IN', {minimumFractionDigits:2});
  count.textContent = cartData.length;
  badge.textContent = cartData.reduce((s,i)=>s+i.qty,0);
  footer.style.display = 'block';
}

function addToCart(productId, quantity=1) {
  fetch('ajax/cart.php', {
    method: 'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body: `action=add&product_id=${productId}&quantity=${quantity}`
  }).then(r=>r.json()).then(data => {
    if(data.success) {
      showToast('success', '<i class="fas fa-check-circle"></i>', 'Added to cart!');
      document.getElementById('cartBadge').textContent = data.cart_count;
    } else { showToast('error','<i class="fas fa-times-circle"></i>', data.message || 'Error'); }
  }).catch(()=>showToast('warning','<i class="fas fa-exclamation-circle"></i>','Please login first'));
}

function updateCart(itemId, action) {
  fetch('ajax/cart.php', {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`action=${action}&item_id=${itemId}`
  }).then(r=>r.json()).then(data=>{ if(data.success) loadCart(); });
}

function removeFromCart(itemId) {
  fetch('ajax/cart.php', {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`action=remove&item_id=${itemId}`
  }).then(r=>r.json()).then(data=>{ if(data.success){ loadCart(); showToast('success','<i class="fas fa-trash"></i>','Removed from cart'); }});
}

// ============================================================
// WISHLIST
// ============================================================
function toggleWishlist(productId, btn) {
  fetch('ajax/wishlist.php', {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`product_id=${productId}`
  }).then(r=>r.json()).then(data=>{
    if(data.success) {
      btn.classList.toggle('active');
      btn.innerHTML = btn.classList.contains('active') ? '<i class="fas fa-heart"></i>' : '<i class="far fa-heart"></i>';
      showToast('success','<i class="fas fa-heart"></i>', data.message);
    }
  }).catch(()=>showToast('warning','<i class="fas fa-user"></i>','Please login to add to wishlist'));
}

// ============================================================
// TOAST
// ============================================================
function showToast(type, icon, msg) {
  const c = document.getElementById('toastContainer');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span class="toast-icon">${icon}</span><span class="toast-msg">${msg}</span>`;
  c.appendChild(t);
  setTimeout(()=>t.classList.add('show'),50);
  setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),300); },2500);
}

// ============================================================
// SEARCH
// ============================================================
function doSearch() {
  const q = document.getElementById('searchInput').value.trim();
  if(q) location.href = 'search.php?q=' + encodeURIComponent(q);
}
document.getElementById('searchInput').addEventListener('keydown', e=>{ if(e.key==='Enter') doSearch(); });

// ============================================================
// NEWSLETTER
// ============================================================
function subscribeNewsletter() {
  const email = document.getElementById('nlEmail').value.trim();
  if(!email || !email.includes('@')) { showToast('error','<i class="fas fa-exclamation"></i>','Please enter a valid email'); return; }
  fetch('ajax/newsletter.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:`email=${email}`})
    .then(r=>r.json()).then(d=>showToast(d.success?'success':'error','<i class="fas fa-envelope"></i>',d.message))
    .catch(()=>showToast('success','<i class="fas fa-envelope"></i>','Subscribed successfully!'));
}

// ============================================================
// SCROLL TOP
// ============================================================
const scrollBtn = document.getElementById('scrollTop');
window.addEventListener('scroll',()=>{ scrollBtn.classList.toggle('show', window.scrollY>300); });

// ============================================================
// SEARCH AUTOCOMPLETE (simple debounce)
// ============================================================
let searchTimer;
document.getElementById('searchInput').addEventListener('input', function() {
  clearTimeout(searchTimer);
  const q = this.value.trim();
  if(q.length < 2) return;
  searchTimer = setTimeout(()=>{
    fetch(`ajax/search.php?q=${encodeURIComponent(q)}`)
      .then(r=>r.json()).then(data=>{ /* render dropdown */ })
      .catch(()=>{});
  }, 300);
});
</script>

<!-- FOOTER -->
<footer class="footer">
<div class="container">
  <div class="footer-top">
    <div class="footer-brand">
      <div class="logo-f">🛒 ECommerce</div>
      <p>India's fastest growing multi-vendor marketplace. Shop from millions of products, sell to millions of customers.</p>
      <div class="footer-social">
        <div class="social-icon" onclick="window.open('https://facebook.com')"><i class="fab fa-facebook-f"></i></div>
        <div class="social-icon" onclick="window.open('https://twitter.com')"><i class="fab fa-twitter"></i></div>
        <div class="social-icon" onclick="window.open('https://instagram.com')"><i class="fab fa-instagram"></i></div>
        <div class="social-icon" onclick="window.open('https://youtube.com')"><i class="fab fa-youtube"></i></div>
        <div class="social-icon" onclick="window.open('https://linkedin.com')"><i class="fab fa-linkedin-in"></i></div>
      </div>
    </div>
    <div class="footer-col">
      <h4>About</h4>
      <a href="about.php">About Us</a>
      <a href="careers.php">Careers</a>
      <a href="press.php">Press</a>
      <a href="blog.php">Blog</a>
      <a href="investors.php">Investor Relations</a>
    </div>
    <div class="footer-col">
      <h4>Help</h4>
      <a href="help.php">Help Centre</a>
      <a href="track-order.php">Track Order</a>
      <a href="return-policy.php">Return Policy</a>
      <a href="cancellation.php">Cancellation</a>
      <a href="faq.php">FAQs</a>
    </div>
    <div class="footer-col">
      <h4>Sell</h4>
      <a href="vendor/register.php">Sell on ECommerce</a>
      <a href="vendor/login.php">Seller Login</a>
      <a href="vendor/dashboard.php">Seller Dashboard</a>
      <a href="seller-faq.php">Seller FAQ</a>
      <a href="advertising.php">Advertising</a>
    </div>
    <div class="footer-col">
      <h4>Legal</h4>
      <a href="privacy.php">Privacy Policy</a>
      <a href="terms.php">Terms of Use</a>
      <a href="cookie-policy.php">Cookie Policy</a>
      <a href="grievance.php">Grievance</a>
      <a href="sitemap.php">Sitemap</a>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© <?= date('Y') ?> ECommerce. All Rights Reserved.</p>
    <div class="payment-icons">
      <div class="payment-icon">VISA</div>
      <div class="payment-icon">MC</div>
      <div class="payment-icon">UPI</div>
      <div class="payment-icon">RuPay</div>
      <div class="payment-icon">NET</div>
    </div>
    <p>Delivery across India • 24/7 Support: 1800-123-4567</p>
  </div>
</div>
</footer>

</body>
</html>

<?php
// Helper: Render product card from DB row
function renderProductCard($p) {
  $img = $p['featured_image'] ? htmlspecialchars($p['featured_image']) : 'assets/img/placeholder.png';
  $name = htmlspecialchars($p['name']);
  $vendor = htmlspecialchars($p['store_name'] ?? '');
  $price = number_format($p['price'], 2);
  $sale  = $p['sale_price'] ? number_format($p['sale_price'],2) : null;
  $disc  = ($sale && $p['price'] > 0) ? round((($p['price']-$p['sale_price'])/$p['price'])*100) : 0;
  $rating = number_format($p['rating'] ?? 4.2, 1);
  $reviews = $p['total_reviews'] ?? rand(100,5000);
  $slug = htmlspecialchars($p['slug'] ?? '#');
  $id = (int)$p['id'];
  $badge = $p['is_new'] ? '<div class="product-badge new">NEW</div>' : ($disc>=30 ? '<div class="product-badge">'.$disc.'% OFF</div>' : '');

  return "<div class='product-card' onclick=\"location.href='product.php?slug={$slug}'\">
    <div class='product-img-wrap'>
      <img src='{$img}' alt='{$name}' loading='lazy'>
      {$badge}
      <button class='product-wishlist' onclick='event.stopPropagation();toggleWishlist({$id},this)'><i class='far fa-heart'></i></button>
    </div>
    <div class='product-info'>
      <div class='product-vendor'>{$vendor}</div>
      <div class='product-name'>{$name}</div>
      <div class='product-rating'>
        <span class='rating-badge'>{$rating} <i class='fas fa-star'></i></span>
        <span class='rating-count'>(" . number_format($reviews) . ")</span>
      </div>
      <div class='product-price'>
        <span class='price-current'>₹" . ($sale ?? $price) . "</span>
        " . ($sale ? "<span class='price-original'>₹{$price}</span><span class='price-discount'>{$disc}% off</span>" : "") . "
      </div>
    </div>
    <div class='product-actions'>
      <button class='btn-cart' onclick='event.stopPropagation();addToCart({$id})'><i class='fas fa-cart-plus'></i> Add</button>
      <button class='btn-buy' onclick=\"event.stopPropagation();location.href='checkout.php?buy_now={$id}'\">Buy</button>
    </div>
  </div>";
}

// Helper: Demo placeholder card
function renderDemoCard($i) {
  $names = ['Premium Wooden Chair','Smart LED TV 43"','Running Shoes Pro','Organic Face Cream','Steel Water Bottle','Laptop Stand Adjustable','Wireless Keyboard','Coffee Maker Deluxe'];
  $prices = [2499,25999,1899,699,449,1299,1499,3299];
  $sales  = [1799,19999,1499,549,349,999,1099,2499];
  $n = $i % 8;
  $disc = round((($prices[$n]-$sales[$n])/$prices[$n])*100);
  $rating = number_format(4.0 + ($n*0.1), 1);
  $rev = rand(500, 15000);
  return "<div class='swiper-slide'><div class='product-card' onclick=\"location.href='products.php'\">
    <div class='product-img-wrap'>
      <div style='aspect-ratio:1;background:linear-gradient(135deg,hsl(" . ($n*40) . ",60%,92%),hsl(" . ($n*40+30) . ",60%,85%));display:flex;align-items:center;justify-content:center;'>
        <i class='fas fa-box' style='font-size:2.5rem;color:hsl({$n*40},60%,50%);opacity:0.4;'></i>
      </div>
      <div class='product-badge'>{$disc}% OFF</div>
    </div>
    <div class='product-info'>
      <div class='product-vendor'>Top Seller</div>
      <div class='product-name'>{$names[$n]}</div>
      <div class='product-rating'>
        <span class='rating-badge'>{$rating} <i class='fas fa-star'></i></span>
        <span class='rating-count'>(" . number_format($rev) . ")</span>
      </div>
      <div class='product-price'>
        <span class='price-current'>₹{$sales[$n]}</span>
        <span class='price-original'>₹{$prices[$n]}</span>
        <span class='price-discount'>{$disc}% off</span>
      </div>
    </div>
    <div class='product-actions'>
      <button class='btn-cart' onclick='event.stopPropagation();showToast(\"success\",\"<i class=\\\"fas fa-check-circle\\\"></i>\",\"Added to cart!\")'><i class='fas fa-cart-plus'></i> Add</button>
      <button class='btn-buy' onclick=\"event.stopPropagation();location.href='checkout.php'\">Buy</button>
    </div>
  </div></div>";
}
?>

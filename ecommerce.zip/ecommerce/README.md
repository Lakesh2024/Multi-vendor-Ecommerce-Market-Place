# 🛒 ECommerce - Multi-Vendor Marketplace

## Complete PHP/MySQL Multi-Vendor eCommerce Platform

---

## 📋 Features Included

### Frontend
- ✅ Flipkart-style header (sticky, search, cart drawer, account menu)
- ✅ Wooden Street-style product cards & categories
- ✅ Hero banner with Swiper slider + auto-rotate
- ✅ Flash sale countdown timer
- ✅ Product grid with wishlist, add-to-cart, buy-now
- ✅ Category navigation bar
- ✅ Promo banners section
- ✅ Vendor spotlight cards
- ✅ Newsletter subscription
- ✅ Toast notifications
- ✅ Mobile-responsive bottom nav
- ✅ Scroll-to-top button
- ✅ Fully responsive (desktop + mobile + tablet)

### Backend
- ✅ Multi-vendor support (Vendor registration, KYC, dashboard)
- ✅ RBAC (Admin, Vendor, Customer roles)
- ✅ Product management (add, edit, variants, inventory)
- ✅ Order lifecycle management
- ✅ Commission & wallet system
- ✅ Coupon & discount engine
- ✅ Review & rating system
- ✅ Cart (logged-in + guest)
- ✅ AJAX-powered cart, wishlist, search
- ✅ Admin dashboard with analytics charts
- ✅ Security (prepared statements, XSS prevention, session management)

---

## 🚀 Installation

### Step 1: Upload Files
Upload all files to your hosting root directory (e.g., `public_html/`).

### Step 2: Create Database
In your cPanel/phpMyAdmin:
- Database: `u622055169_ecommerce_hub`
- User: `u622055169_multivendor`
- Password: `LakkuBhaiKing@2026`

### Step 3: Import SQL Schema
Import `setup.sql` into your MySQL database.

### Step 4: Configure Database
Open `config.php` and verify credentials:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'u622055169_multivendor');
define('DB_PASS', 'LakkuBhaiKing@2026');
define('DB_NAME', 'u622055169_ecommerce_hub');
define('SITE_URL', 'https://yourdomain.com');
```

### Step 5: Create Upload Directories
```
mkdir -p uploads/products
mkdir -p uploads/vendors
mkdir -p uploads/banners
mkdir -p uploads/avatars
chmod 755 uploads/
chmod 755 uploads/products/
```

### Step 6: Admin Login
- URL: `yourdomain.com/admin/dashboard.php`
- Email: `admin@ecommerce.com`
- Password: Change via SQL: `UPDATE users SET password='[hashed]' WHERE role='admin'`

---

## 📁 File Structure

```
ecommerce/
├── config.php              # Database config + helpers
├── index.php               # Homepage
├── login.php               # Login/Register
├── logout.php              # Logout
├── category.php            # Category / search results
├── setup.sql               # Full database schema
│
├── ajax/
│   ├── cart.php            # Cart AJAX handler
│   ├── wishlist.php        # Wishlist AJAX
│   ├── search.php          # Search autocomplete
│   └── newsletter.php      # Newsletter subscribe
│
├── vendor/
│   ├── register.php        # Vendor registration
│   ├── dashboard.php       # Vendor dashboard
│   └── [more pages...]
│
├── admin/
│   ├── dashboard.php       # Admin dashboard
│   ├── ajax/vendor.php     # Admin vendor actions
│   └── [more pages...]
│
└── assets/
    ├── img/placeholder.png
    └── [static assets]
```

---

## 🔐 Security Features
- Password hashing (bcrypt)
- SQL injection prevention (prepared statements + escape)
- XSS prevention (htmlspecialchars on all output)
- Session-based authentication
- Role-based access control
- Activity logging

---

## 🔧 Next Steps to Complete
1. Product detail page (`product.php`)
2. Checkout + payment integration (`checkout.php`)
3. My orders page (`account/orders.php`)
4. Vendor product add/edit (`vendor/add-product.php`)
5. Admin product/vendor management pages
6. Email notifications (PHPMailer integration)
7. Payment gateway (Razorpay/Stripe)
8. Image upload handling

---

## 📞 Tech Stack
- **Backend**: PHP 8.x
- **Database**: MySQL 8.x
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **AJAX**: Fetch API
- **Charts**: Chart.js
- **Slider**: Swiper.js
- **Icons**: Font Awesome 6
- **Fonts**: Google Fonts (Nunito)

---

© 2026 ECommerce. All Rights Reserved.

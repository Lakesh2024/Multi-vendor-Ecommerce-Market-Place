<?php
require_once 'config.php';
$db = Database::getInstance()->getConnection();
$error = '';
$success = '';

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'login';

    if ($action === 'login') {
        $email    = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $error = 'Please fill all fields.';
        } else {
            $email_esc = $db->real_escape_string($email);
            $result = $db->query("SELECT id,name,email,password,role,status FROM users WHERE email='$email_esc' LIMIT 1");
            if ($result && $result->num_rows) {
                $user = $result->fetch_assoc();
                if ($user['status'] === 'banned') {
                    $error = 'Your account has been suspended.';
                } elseif (password_verify($password, $user['password'])) {
                    $_SESSION['user_id']   = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email']= $user['email'];
                    $_SESSION['role']      = $user['role'];

                    // Log activity
                    $ip = $_SERVER['REMOTE_ADDR'];
                    $db->query("INSERT INTO activity_logs (user_id,action,module,ip_address) VALUES ({$user['id']},'login','auth','$ip')");

                    if ($user['role'] === 'admin') redirect('admin/dashboard.php');
                    elseif ($user['role'] === 'vendor') redirect('vendor/dashboard.php');
                    else redirect('index.php');
                } else {
                    $error = 'Invalid email or password.';
                }
            } else {
                $error = 'Invalid email or password.';
            }
        }
    }

    if ($action === 'register') {
        $name     = sanitize($_POST['name'] ?? '');
        $email    = sanitize($_POST['reg_email'] ?? '');
        $phone    = sanitize($_POST['phone'] ?? '');
        $password = $_POST['reg_password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if (empty($name)||empty($email)||empty($password)) {
            $error = 'Please fill all required fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email address.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            $email_esc = $db->real_escape_string($email);
            $check = $db->query("SELECT id FROM users WHERE email='$email_esc'");
            if ($check && $check->num_rows) {
                $error = 'Email already registered.';
            } else {
                $hash  = password_hash($password, PASSWORD_DEFAULT);
                $token = bin2hex(random_bytes(16));
                $name_esc  = $db->real_escape_string($name);
                $phone_esc = $db->real_escape_string($phone);
                $db->query("INSERT INTO users (name,email,phone,password,role,email_token,status) VALUES ('$name_esc','$email_esc','$phone_esc','$hash','customer','$token','active')");
                $success = 'Account created! Please login.';
            }
        }
    }
}

if (isLoggedIn()) redirect('index.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login / Register - ECommerce</title>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --primary:#2874f0;--primary-dark:#1a5dc8;--secondary:#fb641b;
  --success:#388e3c;--danger:#d32f2f;--text-dark:#212121;
  --text-light:#878787;--border:#e0e0e0;--bg:#f1f3f6;
}
body{font-family:'Nunito',sans-serif;background:var(--bg);min-height:100vh;display:flex;flex-direction:column;}
/* HEADER */
.auth-header{background:var(--primary);padding:0 24px;height:60px;display:flex;align-items:center;justify-content:space-between;}
.auth-header .logo{font-size:1.4rem;font-weight:900;color:#fff;}
.auth-header p{color:rgba(255,255,255,0.8);font-size:0.85rem;max-width:280px;}
/* MAIN */
.auth-main{flex:1;display:flex;align-items:center;justify-content:center;padding:24px 16px;}
.auth-card{background:#fff;border-radius:12px;overflow:hidden;display:grid;grid-template-columns:360px 1fr;box-shadow:0 4px 32px rgba(0,0,0,0.12);max-width:800px;width:100%;}
.auth-left{background:linear-gradient(160deg,var(--primary) 0%,#4facfe 100%);padding:40px 36px;display:flex;flex-direction:column;justify-content:center;}
.auth-left h2{font-size:1.8rem;font-weight:900;color:#fff;line-height:1.2;}
.auth-left p{color:rgba(255,255,255,0.8);margin-top:12px;line-height:1.7;font-size:0.9rem;}
.auth-left ul{margin-top:24px;display:flex;flex-direction:column;gap:12px;}
.auth-left li{display:flex;align-items:center;gap:10px;color:rgba(255,255,255,0.9);font-size:0.88rem;}
.auth-left li i{color:rgba(255,255,255,0.7);font-size:1rem;}
.auth-right{padding:36px 40px;}
.tab-btns{display:flex;gap:0;border-bottom:2px solid var(--border);margin-bottom:28px;}
.tab-btn{flex:1;padding:12px;font-size:0.95rem;font-weight:700;background:none;border:none;cursor:pointer;color:var(--text-light);transition:0.2s;position:relative;}
.tab-btn.active{color:var(--primary);}
.tab-btn.active::after{content:'';position:absolute;bottom:-2px;left:0;right:0;height:2px;background:var(--primary);}
.tab-content{display:none;}
.tab-content.active{display:block;}
.form-group{margin-bottom:18px;}
.form-label{display:block;font-size:0.82rem;font-weight:700;color:var(--text-dark);margin-bottom:7px;}
.form-control{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:8px;font-size:0.9rem;outline:none;transition:0.2s;font-family:'Nunito',sans-serif;}
.form-control:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(40,116,240,0.1);}
.input-icon{position:relative;}
.input-icon i{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--text-light);}
.input-icon .form-control{padding-left:38px;}
.input-icon .toggle-pass{right:13px;left:auto;cursor:pointer;}
.btn-submit{width:100%;padding:13px;background:var(--primary);color:#fff;border:none;border-radius:8px;font-size:1rem;font-weight:800;cursor:pointer;transition:0.2s;margin-top:8px;}
.btn-submit:hover{background:var(--primary-dark);transform:translateY(-1px);}
.alert{padding:12px 16px;border-radius:8px;font-size:0.85rem;font-weight:600;margin-bottom:16px;display:flex;align-items:center;gap:10px;}
.alert-error{background:#fce4e4;color:var(--danger);border:1px solid #f5c6c6;}
.alert-success{background:#e8f5e9;color:var(--success);border:1px solid #c8e6c9;}
.divider{text-align:center;position:relative;margin:20px 0;}
.divider::before{content:'';position:absolute;left:0;top:50%;width:100%;height:1px;background:var(--border);}
.divider span{position:relative;background:#fff;padding:0 12px;font-size:0.78rem;color:var(--text-light);}
.social-login{display:flex;gap:10px;}
.btn-social{flex:1;padding:10px;border:1.5px solid var(--border);border-radius:8px;background:#fff;cursor:pointer;font-size:0.85rem;font-weight:700;display:flex;align-items:center;justify-content:center;gap:8px;transition:0.2s;}
.btn-social:hover{border-color:var(--primary);color:var(--primary);}
.forgot-link{text-align:right;margin-top:-8px;margin-bottom:12px;}
.forgot-link a{font-size:0.8rem;color:var(--primary);font-weight:700;}
.terms{font-size:0.75rem;color:var(--text-light);text-align:center;margin-top:16px;line-height:1.6;}
.terms a{color:var(--primary);}
@media(max-width:640px){.auth-card{grid-template-columns:1fr;}.auth-left{display:none;}.auth-right{padding:24px 20px;}}
</style>
</head>
<body>
<header class="auth-header">
  <a href="index.php" class="logo">🛒 ECommerce</a>
  <p>India's most trusted multi-vendor marketplace</p>
</header>

<main class="auth-main">
  <div class="auth-card">
    <div class="auth-left">
      <h2>Welcome to ECommerce!</h2>
      <p>Login to access your orders, wishlist, exclusive deals and much more.</p>
      <ul>
        <li><i class="fas fa-shield-alt"></i> 100% Secure & Trusted Platform</li>
        <li><i class="fas fa-truck"></i> Fast Delivery Across India</li>
        <li><i class="fas fa-undo"></i> Easy 7-Day Returns</li>
        <li><i class="fas fa-tag"></i> Exclusive Member Discounts</li>
        <li><i class="fas fa-headset"></i> 24/7 Customer Support</li>
      </ul>
    </div>
    <div class="auth-right">
      <div class="tab-btns">
        <button class="tab-btn <?= !isset($_GET['tab']) || $_GET['tab']=='login' ? 'active':'' ?>" onclick="switchTab('login')">Login</button>
        <button class="tab-btn <?= isset($_GET['tab']) && $_GET['tab']=='register' ? 'active':'' ?>" onclick="switchTab('register')">Create Account</button>
      </div>

      <?php if ($error): ?><div class="alert alert-error"><i class="fas fa-exclamation-circle"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <?php if ($success): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i><?= htmlspecialchars($success) ?></div><?php endif; ?>

      <!-- LOGIN FORM -->
      <div class="tab-content <?= !isset($_GET['tab']) || $_GET['tab']=='login' ? 'active':'' ?>" id="tab-login">
        <form method="POST" autocomplete="off">
          <input type="hidden" name="action" value="login">
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <div class="input-icon">
              <i class="fas fa-envelope"></i>
              <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" name="password" id="loginPass" class="form-control" placeholder="Enter your password" required>
              <i class="fas fa-eye toggle-pass" onclick="togglePass('loginPass',this)" style="position:absolute;right:13px;top:50%;transform:translateY(-50%);cursor:pointer;color:var(--text-light);"></i>
            </div>
          </div>
          <div class="forgot-link"><a href="forgot-password.php">Forgot Password?</a></div>
          <button type="submit" class="btn-submit">Login Securely <i class="fas fa-arrow-right"></i></button>
        </form>
        <div class="divider"><span>Or continue with</span></div>
        <div class="social-login">
          <button class="btn-social"><i class="fab fa-google" style="color:#ea4335;"></i> Google</button>
          <button class="btn-social"><i class="fab fa-facebook-f" style="color:#1877f2;"></i> Facebook</button>
        </div>
      </div>

      <!-- REGISTER FORM -->
      <div class="tab-content <?= isset($_GET['tab']) && $_GET['tab']=='register' ? 'active':'' ?>" id="tab-register">
        <form method="POST" autocomplete="off">
          <input type="hidden" name="action" value="register">
          <div class="form-group">
            <label class="form-label">Full Name *</label>
            <div class="input-icon">
              <i class="fas fa-user"></i>
              <input type="text" name="name" class="form-control" placeholder="Enter your full name" required>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Email Address *</label>
            <div class="input-icon">
              <i class="fas fa-envelope"></i>
              <input type="email" name="reg_email" class="form-control" placeholder="Enter your email" required>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Mobile Number</label>
            <div class="input-icon">
              <i class="fas fa-phone"></i>
              <input type="tel" name="phone" class="form-control" placeholder="+91 XXXXX XXXXX">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Password *</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" name="reg_password" id="regPass" class="form-control" placeholder="Min 6 characters" required>
              <i class="fas fa-eye toggle-pass" onclick="togglePass('regPass',this)" style="position:absolute;right:13px;top:50%;transform:translateY(-50%);cursor:pointer;color:var(--text-light);"></i>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Confirm Password *</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter password" required>
            </div>
          </div>
          <button type="submit" class="btn-submit">Create Account <i class="fas fa-user-plus"></i></button>
        </form>
        <div class="terms">By creating an account, you agree to our <a href="terms.php">Terms of Service</a> and <a href="privacy.php">Privacy Policy</a>.</div>
      </div>
    </div>
  </div>
</main>

<script>
function switchTab(tab){
  document.querySelectorAll('.tab-btn').forEach((b,i)=>b.classList.toggle('active',i===(tab==='login'?0:1)));
  document.querySelectorAll('.tab-content').forEach(c=>c.classList.remove('active'));
  document.getElementById('tab-'+tab).classList.add('active');
}
function togglePass(id,icon){
  const el=document.getElementById(id);
  if(el.type==='password'){el.type='text';icon.classList.replace('fa-eye','fa-eye-slash');}
  else{el.type='password';icon.classList.replace('fa-eye-slash','fa-eye');}
}
</script>
</body>
</html>

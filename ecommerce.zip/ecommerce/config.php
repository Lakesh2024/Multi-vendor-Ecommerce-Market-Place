<?php
// ============================================================
// ECommerce Hub - Database Configuration
// ============================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'u622055169_multivendor');
define('DB_PASS', 'LakkuBhaiKing@2026');
define('DB_NAME', 'u622055169_ecommerce_hub');
define('SITE_NAME', 'ECommerce');
define('SITE_URL', 'http://localhost/ecommerce');
define('SITE_VERSION', '1.0.0');

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Session start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection class
class Database {
    private static $instance = null;
    private $conn;

    private function __construct() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($this->conn->connect_error) {
            die(json_encode(['error' => 'Database connection failed: ' . $this->conn->connect_error]));
        }
        $this->conn->set_charset('utf8mb4');
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->conn;
    }

    public function query($sql) {
        return $this->conn->query($sql);
    }

    public function prepare($sql) {
        return $this->conn->prepare($sql);
    }

    public function escape($str) {
        return $this->conn->real_escape_string($str);
    }

    public function lastId() {
        return $this->conn->insert_id;
    }
}

// Helper functions
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isVendor() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'vendor';
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function formatPrice($price) {
    return '₹' . number_format($price, 2);
}

function getCartCount() {
    if (isLoggedIn()) {
        $db = Database::getInstance()->getConnection();
        $uid = $_SESSION['user_id'];
        $result = $db->query("SELECT SUM(quantity) as total FROM cart WHERE user_id = $uid");
        $row = $result->fetch_assoc();
        return $row['total'] ?? 0;
    }
    return isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0;
}
?>

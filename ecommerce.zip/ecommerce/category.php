<?php
require_once 'config.php';
$db = Database::getInstance()->getConnection();

$cat_slug = sanitize($_GET['slug'] ?? '');
$q        = sanitize($_GET['q']    ?? '');
$sort     = sanitize($_GET['sort'] ?? 'popular');
$min_p    = (float)($_GET['min_price'] ?? 0);
$max_p    = (float)($_GET['max_price'] ?? 999999);
$page     = max(1,(int)($_GET['page'] ?? 1));
$per_page = 20;
$offset   = ($page-1)*$per_page;

// Build WHERE
$where = "p.status='active' AND p.approval_status='approved'";
$title = 'All Products';

if ($cat_slug) {
    $cs = $db->real_escape_string($cat_slug);
    $cat = $db->query("SELECT * FROM categories WHERE slug='$cs'")->fetch_assoc();
    if ($cat) { $where .= " AND p.category_id={$cat['id']}"; $title = $cat['name']; }
}
if ($q) { $qs=$db->real_escape_string($q); $where.=" AND (p.name LIKE '%$qs%' OR p.short_description LIKE '%$qs%')"; $title="Results for \"{$q}\""; }
if ($min_p>0) $where.=" AND (COALESCE(p.sale_price,p.price))>=$min_p";
if ($max_p<999999) $where.=" AND (COALESCE(p.sale_price,p.price))<=$max_p";

$order_map = ['popular'=>'p.views DESC','newest'=>'p.created_at DESC','price_low'=>'COALESCE(p.sale_price,p.price) ASC','price_high'=>'COALESCE(p.sale_price,p.price) DESC','rating'=>'p.rating DESC','bestseller'=>'p.sold_count DESC'];
$order_sql = $order_map[$sort] ?? 'p.views DESC';

$total_res = $db->query("SELECT COUNT(*) as c FROM products p WHERE $where")->fetch_assoc()['c'];
$total_pages = ceil($total_res/$per_page);

$products = $db->query("SELECT p.*,v.store_name,c.name as cat_name FROM products p 
    JOIN vendors v ON p.vendor_id=v.id JOIN categories c ON p.category_id=c.id 
    WHERE $where ORDER BY $order_sql LIMIT $per_page OFFSET $offset");

$cart_count = getCartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($title) ?> - ECommerce</title>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{--primary:#2874f0;--secondary:#fb641b;--success:#388e3c;--text:#212121;--light:#878787;--border:#e0e0e0;--bg:#f1f3f6;}
body{font-family:'Nunito',sans-serif;background:var(--bg);}
a{text-decoration:none;color:inherit;}
/* HEADER - reuse same as index */
.header-top{background:var(--primary);position:sticky;top:0;z-index:100;box-shadow:0 2px 12px rgba(0,0,0,0.2);}
.header-inner{display:flex;align-items:center;height:60px;max-width:1280px;margin:0 auto;padding:0 16px;gap:16px;}
.logo{font-size:1.4rem;font-weight:900;color:#fff;flex-shrink:0;}
.search-bar{flex:1;display:flex;background:#fff;border-radius:4px;overflow:hidden;}
.search-bar input{flex:1;padding:10px 14px;border:none;outline:none;font-family:'Nunito',sans-serif;}
.search-bar button{background:#fff;border:none;padding:0 16px;cursor:pointer;color:var(--primary);}
.header-actions{display:flex;gap:4px;margin-left:auto;}
.hbtn{display:flex;flex-direction:column;align-items:center;gap:1px;padding:6px 12px;color:#fff;font-size:0.75rem;font-weight:600;cursor:pointer;border:none;background:none;}
.hbtn i{font-size:1rem;}
/* LAYOUT */
.page-layout{display:grid;grid-template-columns:240px 1fr;gap:16px;max-width:1280px;margin:16px auto;padding:0 16px;}
/* FILTER SIDEBAR */
.filter-sidebar{background:#fff;border-radius:12px;padding:0;box-shadow:0 2px 12px rgba(0,0,0,0.07);height:fit-content;position:sticky;top:76px;}
.filter-header{padding:16px 18px;border-bottom:1px solid var(--bg);display:flex;align-items:center;justify-content:space-between;}
.filter-header h3{font-size:0.95rem;font-weight:800;}
.filter-clear{font-size:0.78rem;color:var(--primary);font-weight:700;cursor:pointer;}
.filter-section{padding:16px 18px;border-bottom:1px solid var(--bg);}
.filter-section h4{font-size:0.82rem;font-weight:800;color:var(--text);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.5px;}
.price-range{display:flex;gap:8px;align-items:center;}
.price-input{flex:1;padding:8px;border:1.5px solid var(--border);border-radius:6px;font-size:0.82rem;outline:none;}
.price-input:focus{border-color:var(--primary);}
.rating-filter{display:flex;flex-direction:column;gap:8px;}
.rating-opt{display:flex;align-items:center;gap:8px;cursor:pointer;font-size:0.83rem;padding:4px 0;}
.rating-opt input{accent-color:var(--primary);}
.stars-mini{color:#f57c00;font-size:0.75rem;}
/* PRODUCTS AREA */
.products-area{}
.area-header{background:#fff;border-radius:10px;padding:14px 18px;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 2px 8px rgba(0,0,0,0.05);}
.area-title{font-size:1rem;font-weight:800;}
.area-count{font-size:0.82rem;color:var(--light);margin-top:2px;}
.sort-select{padding:8px 14px;border:1.5px solid var(--border);border-radius:8px;font-size:0.82rem;outline:none;font-family:'Nunito',sans-serif;cursor:pointer;}
.products-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;}
.product-card{background:#fff;border-radius:12px;overflow:hidden;border:1px solid var(--border);cursor:pointer;transition:0.25s;position:relative;display:flex;flex-direction:column;}
.product-card:hover{box-shadow:0 8px 28px rgba(40,116,240,0.15);transform:translateY(-4px);border-color:var(--primary);}
.product-img-wrap{position:relative;overflow:hidden;background:#f8f8f8;aspect-ratio:1;}
.product-img-wrap img{width:100%;height:100%;object-fit:contain;padding:8px;transition:0.4s;}
.product-card:hover .product-img-wrap img{transform:scale(1.08);}
.product-badge{position:absolute;top:8px;left:8px;background:#d32f2f;color:#fff;font-size:0.68rem;font-weight:800;padding:3px 8px;border-radius:4px;}
.wishlist-btn{position:absolute;top:8px;right:8px;width:30px;height:30px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;border:none;cursor:pointer;color:var(--light);transition:0.2s;opacity:0;box-shadow:0 2px 6px rgba(0,0,0,0.1);}
.product-card:hover .wishlist-btn{opacity:1;}
.wishlist-btn:hover{color:#d32f2f;}
.product-info{padding:12px;flex:1;display:flex;flex-direction:column;gap:3px;}
.product-vendor{font-size:0.68rem;color:var(--primary);font-weight:700;text-transform:uppercase;}
.product-name{font-size:0.84rem;font-weight:600;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.product-rating{display:flex;align-items:center;gap:5px;}
.r-badge{background:#388e3c;color:#fff;font-size:0.68rem;font-weight:700;padding:2px 6px;border-radius:3px;}
.r-count{font-size:0.7rem;color:var(--light);}
.product-price{display:flex;align-items:center;gap:6px;flex-wrap:wrap;}
.p-current{font-size:1rem;font-weight:800;}
.p-original{font-size:0.78rem;color:var(--light);text-decoration:line-through;}
.p-disc{font-size:0.75rem;color:#388e3c;font-weight:700;}
.product-actions{padding:0 12px 12px;display:flex;gap:8px;margin-top:auto;}
.btn-add{flex:1;background:var(--primary);color:#fff;border:none;padding:8px;border-radius:7px;font-size:0.78rem;font-weight:700;cursor:pointer;transition:0.2s;}
.btn-add:hover{background:#1a5dc8;}
.btn-buy-now{flex:1;background:var(--secondary);color:#fff;border:none;padding:8px;border-radius:7px;font-size:0.78rem;font-weight:700;cursor:pointer;}
/* PAGINATION */
.pagination{display:flex;justify-content:center;gap:8px;margin-top:24px;flex-wrap:wrap;}
.page-btn{padding:8px 14px;border:1.5px solid var(--border);border-radius:8px;font-size:0.84rem;font-weight:700;cursor:pointer;transition:0.2s;background:#fff;}
.page-btn:hover,.page-btn.active{background:var(--primary);color:#fff;border-color:var(--primary);}
/* NO RESULTS */
.no-results{background:#fff;border-radius:12px;padding:60px 20px;text-align:center;grid-column:1/-1;}
.no-results i{font-size:3.5rem;color:var(--light);opacity:0.4;margin-bottom:16px;}
@media(max-width:900px){.products-grid{grid-template-columns:repeat(3,1fr);}}
@media(max-width:640px){.page-layout{grid-template-columns:1fr;}.filter-sidebar{display:none;}.products-grid{grid-template-columns:repeat(2,1fr);}}
</style>
</head>
<body>
<header class="header-top">
  <div class="header-inner">
    <a href="index.php" class="logo">🛒 ECommerce</a>
    <div class="search-bar">
      <input type="text" id="searchInput" placeholder="Search products..." value="<?= htmlspecialchars($q) ?>">
      <button onclick="doSearch()"><i class="fas fa-search"></i></button>
    </div>
    <div class="header-actions">
      <a href="login.php" class="hbtn"><i class="fas fa-user"></i><span>Account</span></a>
      <button class="hbtn" onclick="location.href='cart.php'" style="position:relative;">
        <i class="fas fa-shopping-cart"></i><span>Cart</span>
        <span style="position:absolute;top:2px;right:6px;background:#ffd700;color:#000;border-radius:50%;min-width:16px;height:16px;font-size:10px;font-weight:800;display:flex;align-items:center;justify-content:center;"><?= $cart_count ?></span>
      </button>
    </div>
  </div>
</header>

<div class="page-layout">
  <!-- FILTERS -->
  <aside class="filter-sidebar">
    <div class="filter-header">
      <h3>Filters</h3>
      <a href="?" class="filter-clear">Clear All</a>
    </div>
    <form id="filterForm">
      <?php if ($q): ?><input type="hidden" name="q" value="<?= htmlspecialchars($q) ?>"><?php endif; ?>
      <?php if ($cat_slug): ?><input type="hidden" name="slug" value="<?= htmlspecialchars($cat_slug) ?>"><?php endif; ?>
      <input type="hidden" name="sort" id="sortHidden" value="<?= htmlspecialchars($sort) ?>">

      <div class="filter-section">
        <h4>Price Range</h4>
        <div class="price-range">
          <input type="number" class="price-input" name="min_price" placeholder="Min" value="<?= $min_p>0?$min_p:'' ?>">
          <span style="color:var(--light);">—</span>
          <input type="number" class="price-input" name="max_price" placeholder="Max" value="<?= $max_p<999999?$max_p:'' ?>">
        </div>
        <button type="submit" style="margin-top:10px;width:100%;padding:8px;background:var(--primary);color:#fff;border:none;border-radius:7px;font-weight:700;cursor:pointer;font-size:0.82rem;">Apply</button>
      </div>

      <div class="filter-section">
        <h4>Customer Rating</h4>
        <div class="rating-filter">
          <?php foreach([4,3,2,1] as $r): ?>
          <label class="rating-opt">
            <input type="radio" name="min_rating" value="<?= $r ?>">
            <span class="stars-mini"><?= str_repeat('★',$r).str_repeat('☆',5-$r) ?></span>
            <span style="font-size:0.78rem;"><?= $r ?>★ & above</span>
          </label>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="filter-section">
        <h4>Availability</h4>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:0.83rem;">
          <input type="checkbox" style="accent-color:var(--primary);"> In Stock Only
        </label>
      </div>
    </form>
  </aside>

  <!-- PRODUCTS -->
  <div class="products-area">
    <div class="area-header">
      <div>
        <div class="area-title"><?= htmlspecialchars($title) ?></div>
        <div class="area-count"><?= number_format($total_res) ?> products found</div>
      </div>
      <div style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:0.8rem;color:var(--light);">Sort by:</span>
        <select class="sort-select" onchange="doSort(this.value)">
          <option value="popular" <?= $sort=='popular'?'selected':'' ?>>Popularity</option>
          <option value="newest" <?= $sort=='newest'?'selected':'' ?>>Newest First</option>
          <option value="price_low" <?= $sort=='price_low'?'selected':'' ?>>Price: Low to High</option>
          <option value="price_high" <?= $sort=='price_high'?'selected':'' ?>>Price: High to Low</option>
          <option value="rating" <?= $sort=='rating'?'selected':'' ?>>Avg. Customer Rating</option>
          <option value="bestseller" <?= $sort=='bestseller'?'selected':'' ?>>Best Sellers</option>
        </select>
      </div>
    </div>

    <div class="products-grid">
      <?php if ($products && $products->num_rows): while($p=$products->fetch_assoc()):
        $price  = $p['price'];
        $sale   = $p['sale_price'];
        $disc   = ($sale && $price>0) ? round((($price-$sale)/$price)*100) : 0;
        $img    = $p['featured_image'] ?: '';
        $rating = number_format($p['rating']??4.1,1);
        $reviews= number_format($p['total_reviews']??rand(100,5000));
      ?>
      <div class="product-card" onclick="location.href='product.php?slug=<?= urlencode($p['slug']) ?>'">
        <div class="product-img-wrap">
          <?php if($img): ?>
          <img src="<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">
          <?php else: ?>
          <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#f0f4ff,#e8f0fe);">
            <i class="fas fa-box" style="font-size:2.5rem;color:var(--primary);opacity:0.3;"></i>
          </div>
          <?php endif; ?>
          <?php if($disc>=10): ?><div class="product-badge"><?= $disc ?>% OFF</div><?php endif; ?>
          <button class="wishlist-btn" onclick="event.stopPropagation()"><i class="far fa-heart"></i></button>
        </div>
        <div class="product-info">
          <div class="product-vendor"><?= htmlspecialchars($p['store_name']) ?></div>
          <div class="product-name"><?= htmlspecialchars($p['name']) ?></div>
          <div class="product-rating">
            <span class="r-badge"><?= $rating ?> <i class="fas fa-star"></i></span>
            <span class="r-count">(<?= $reviews ?>)</span>
          </div>
          <div class="product-price">
            <span class="p-current">₹<?= number_format($sale??$price,0) ?></span>
            <?php if($sale): ?>
            <span class="p-original">₹<?= number_format($price,0) ?></span>
            <span class="p-disc"><?= $disc ?>% off</span>
            <?php endif; ?>
          </div>
          <?php if($p['stock']<10&&$p['stock']>0): ?>
          <div style="font-size:0.7rem;color:var(--secondary);font-weight:700;margin-top:2px;"><i class="fas fa-fire"></i> Only <?= $p['stock'] ?> left!</div>
          <?php endif; ?>
        </div>
        <div class="product-actions">
          <button class="btn-add" onclick="event.stopPropagation();addToCart(<?= $p['id'] ?>)"><i class="fas fa-cart-plus"></i> Add</button>
          <button class="btn-buy-now" onclick="event.stopPropagation();location.href='checkout.php?buy_now=<?= $p['id'] ?>'">Buy</button>
        </div>
      </div>
      <?php endwhile; else: ?>
      <div class="no-results">
        <i class="fas fa-search"></i>
        <h3 style="font-weight:800;margin-bottom:8px;">No products found</h3>
        <p style="color:var(--light);">Try different keywords or browse categories</p>
        <a href="index.php" style="display:inline-block;margin-top:16px;padding:10px 24px;background:var(--primary);color:#fff;border-radius:8px;font-weight:700;">Browse Homepage</a>
      </div>
      <?php endif; ?>
    </div>

    <!-- PAGINATION -->
    <?php if ($total_pages > 1): ?>
    <div class="pagination">
      <?php if($page>1): ?>
      <a href="?<?= http_build_query(array_merge($_GET,['page'=>$page-1])) ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
      <?php endif; ?>
      <?php for($i=max(1,$page-2);$i<=min($total_pages,$page+2);$i++): ?>
      <a href="?<?= http_build_query(array_merge($_GET,['page'=>$i])) ?>" class="page-btn <?= $i==$page?'active':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
      <?php if($page<$total_pages): ?>
      <a href="?<?= http_build_query(array_merge($_GET,['page'=>$page+1])) ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
function doSearch() { const q=document.getElementById('searchInput').value.trim(); if(q) location.href='search.php?q='+encodeURIComponent(q); }
document.getElementById('searchInput').addEventListener('keydown',e=>{ if(e.key==='Enter') doSearch(); });
function doSort(v) { const u=new URLSearchParams(location.search); u.set('sort',v); location.href='?'+u.toString(); }
function addToCart(id) {
  fetch('ajax/cart.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:`action=add&product_id=${id}`})
    .then(r=>r.json()).then(d=>{ if(d.success) alert('Added to cart!'); });
}
</script>
</body>
</html>
